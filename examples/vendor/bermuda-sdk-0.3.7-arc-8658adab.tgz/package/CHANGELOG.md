# Changelog

## Unreleased

- A withdrawal, private or doxxed (a Safe's through `resolveWithdrawStep` too), picks its inputs among the 16 UTXOs
  carrying the most value it can pay out, as a transfer picks among the 16 with the most compliant value, and on a tie
  the UTXO carrying the least besides. Larger UTXOs of the other kind no longer crowd out the one it withdraws
  (`Unable to progress withdraw amount`).
- A swap's legs no longer have to read the same commitment tree: each leg's inputs open at the root its prelude read,
  and the swap anchors both (`IOtcAssembly.roots`; `buildAssembly` takes no root). A pool transaction landing between
  the two preludes no longer fails pack with `packs disagree on root`. Legs that read one tree sign the same
  `shtx_hash` as before.
- A leg sells from one UTXO, or two of the 16 with the most compliant value, whose compliant components carve into its
  slices: of those, the set with the fewest deposit ids, then the least change. A large, mostly blocklisted UTXO no
  longer pushes a sale two clean UTXOs cover past the two-input cap, and UTXOs spanning more deposit ids than a slice
  holds are refused as such (`sell less at a time`), not with `consolidate first`.
- A swap between a token's two classes whose legs both sell value of one deposit is refused before anyone signs:
  `buildAssembly`, and with it `otc.pack` and `safe.otc`, names the shared deposit id. A flip keeps a note's deposit
  ids, and a proof binds each deposit id to one token, so both legs signed and prove failed with
  `assembly.depositIdToken mismatch`.
- The vendored 31337 circuits are shtx-circuits main f270a41c's (source tree cd4d0d1b), copied byte for byte. Nine of
  them change bytecode and VK with the same ABI and inputs: a repeated non-zero slot, and one party on transact_4x8's
  two spending slots, are refused by one product, and an issuer-policy leaf is ordered by two key comparisons, forms
  that accept exactly the witnesses the old ones did. clawback16 and policyUpdate keep their bytecode. This sdk proves
  for a pool with these verifiers only.
- The bundled pool and PoolConfig ABIs follow pool main ff43137 (pool#389, `scripts/sync-abis.mjs`). PoolConfig gains
  `termsAtMost(level)`, every term in force in one call that reverts `EnforcedPause` while the pause level in force is
  above `level`; `unpausedTerms()` is `termsAtMost(None)`. The pool declares `InvalidRelayerFee` itself: a withdrawal
  whose fee base is out of range reverts `InvalidExtAmount` for an extAmount of `type(int256).min`, or
  `InvalidRelayerFee` for a relay fee that overflows the fee base, in place of a panic. It drops
  `InvalidMerkleProofLength`: a recovery manifest path longer than its tree reverts `InvalidMerkleProof`. No call this
  sdk makes changes.
- The sealed policy list, issuer reply and UTXO cache entry draw their nonce through noble's `managedNonce`, which
  `sealedXChaCha` wraps: their wire format is unchanged, and what was sealed before opens as before. One `isField` and
  one `isGrumpkinScalar` check every field element and Grumpkin scalar, each site with its own zero handling and
  message. All three are new on `/internal`. A number or string is now refused where utxo's checks took it, and
  poseidon2 calls one "not a field element". `nullifierKey` answers undefined, not a negative remainder, when exactly
  one of the tweak and the secret is negative.

### BREAKING: `/internal` drops grumpkin-schnorr's unused exports and parameters

`@bermuda/sdk/internal` no longer exports `scalarFromBytes` or `SHTX_SPEND_AUTH_DOMAIN_MESSAGE`
(`SHTX_SPEND_AUTH_DOMAIN_FIELD` stays). `hashToField` and `hashToFieldScalar` take no `k`, which was always 128, and
`scalarToBytes` no `allowZero`: zero is always refused. No dependent imports any of them. `hpkeSetupBaseS`, which no
entry point re-exported, is private to xwing-xchacha20-poly1305.

### BREAKING: a swap's signer authorizes its own leg alone

A key or a Safe account could be led to authorize its own notes for the counterparty's leg. Two of its swaps, each
answered with its own share of the other, built one assembly: it took its own change for each payment and signed two
slot messages over one `shtx_hash`, and one transact_4x8 proof with it on both slots spent both its notes for its two
changes. A swap of a token for itself landed on a one-slot shape, whose one signature over the bare `shtx_hash` also
covered a note of the signer's that the counterparty listed.

The circuit refuses the first. shtx-circuits f49d9ac7's transact_4x8 refuses two spending slots that stand for one
party, an account by its accountId and a key by its pubkey hash, so a party's two legs never settle as one transact_4x8
proof, whoever proves it. The vendored 31337 circuits were then that commit's (source tree 1acfecac), copied byte for
byte: transact4x8's bytecode and VK changed again, not its inputs or outputs (its `abi.error_types` gained the new
assertion's message), and every other circuit kept its bytecode, ABI and VK; they are now f270a41c's (above). Without
`circuitsBaseUrl`, on 31337 this sdk proves with its bundled circuits, whose transact, withdrawal and recovery proofs
only a pool with shtx-circuits f270a41c's verifiers accepts (above); elsewhere, or with `circuitsBaseUrl` set, it proves
with the circuits served there, which must be its pool's. Use it on a chain once its pool is deployed with those.

A one-slot shape has one spend-auth slot, so no circuit refuses the second. Before anything is signed, `otc.pack` now
refuses, and `safe.otc` with it through `assertOtcTradeSound` and `buildAssembly`:

- a leg that buys the token id it sells, one token in one class (`otc.prelude` too); the two classes of one token still
  swap;
- an assembly on a shape with fewer than two spend-auth slots, 2x4, 2x16 or 16x4 (`buildAssembly`), which only the
  prover refused before, once both legs had signed.

An older sdk still signs the second on every pool, since only these refusals stop it: after one of its swaps did not
land, spend its inputs to yourself.

### BREAKING: every verifier is fixed at construction

The bundled ABIs follow pool main 6b46f96 (pool#383, pool#386), whose pool and registry fix every verifier at
construction: nothing replaces or freezes one. A broken verifier is answered by the governor's pause and a migration to
a new pool (pool SECURITY.md). Nothing in the sdk called the removed entries. The v0.3.7-arc deployment (Arc, 5042)
keeps its replaceable verifiers, which these ABIs no longer name.

- The pool drops `setVerifier`, `applyVerifier`, `freezeVerifier`, `VERIFIER_DELAY_SECONDS`, the events
  `VerifierScheduled`, `VerifierSet` and `VerifierFrozen` and the errors `VerifierNotReady`, `VerifierCodeChanged` and
  `VerifierAlreadyFrozen`. A shape's verifier is read from the creation calldata's `verifiers` tuple or the pool's
  `_shapes` storage (pool README).
- The registry's core drops the same functions, events and errors, `pendingVerifier()`, `isVerifierFrozen()` and
  `NotWired`. Its constructor takes the `policy_update` verifier last,
  `(depth, epochLengthSeconds, graceSeconds, poolConfig, deployer, verifier)` (the bundled one lacked `deployer`),
  `policyUpdateVerifier()` names it as before, and `wire(safeAccounts, inboundPolicies)` takes the modules only.
- The pool links six libraries, one CREATE fewer before it, so every later address moves back by one nonce: `testenv`
  (pool at 27, multiSendCallOnly, batchDelegate, multiSend, signMsgHashLib) and `eez-rollup-x` (pool at 32, multiCall
  at 33, batchDelegate at 34, where its v0.3.6-x deploy put them). testenv's registry call is nonce 3, after the
  `policy_update` verifier's create at 2; the registry's CREATE3 address does not move.

### BREAKING: each transact_4x8 spend-auth slot signs the inputs it spends

transact_4x8 has two spend-auth slots. Each signed the bare `shtx_hash`, and any real input could name either slot, so
the prover of an OTC swap who held another of the signer's notes with its nullifier key, from an earlier pack that
never landed, could list it in its own leg, where the signer's one signature over the swap authorized it. A slot of
transact_4x8 now signs `Poseidon2(SLOT_AUTH_TAG, shtx_hash, mask)`, where `mask` sets bit `i` for each real input `i`
the slot spends, as the circuit computes it from the witness: a key's signature and an account's approvals cover
exactly the inputs at the positions they name. Every other shape signs the `shtx_hash` as before.

- `accountRegistry.spendAuthMessage(shtxHash, slots, nullifiers, own)` is what a slot signs, `inputMask` its mask and
  `SLOT_AUTH_TAG` is `hash_to_field("bermuda:shtx:slot-auth:v1")`. `@bermuda/sdk/internal` exports
  `laneCountForShape`, a shape's slot count.
- `prepareUnsigned` also returns `spendAuthMessage`, which `finalizeWithSignature`'s signature and an account's
  `authDigests` take. On transact_4x8 a signature over the bare `shtx_hash` fails the proof with
  `invalid spend authorization`, and an account's approval over it with
  `counted signature does not verify against the named owner's key`.
- `otc.pack` signs its leg's slot message. An account leg's owners approve
  `spendAuthMessage(assembly.shtxHash, 2, assembly.orderedNullifiers, share.inputNullifiers)`. A leg sells from no
  zero-amount note, an input the mask does not count.
- **It needs the new transact_4x8 verifier.** The vendored 31337 circuits were then shtx-circuits main b18f8b08's
  (source tree 56184b80), copied byte for byte: only transact4x8's bytecode changed, not its ABI, and every other
  circuit kept its bytecode, ABI and VK. They are now f270a41c's (above). This sdk proves no 4x8 proof for a pool with
  the old verifier: where the pool's own circuits from before slot binding are served, an OTC swap, or a transfer that
  takes the 4x8 shape (3 or 4 inputs, or 5 to 8 outputs), fails at proving with `invalid spend authorization`, or for
  an account with `counted signature does not verify against the named owner's key`, before anything is sent; on 31337
  with the bundled circuits, the old verifier rejects the proof. Use it on a chain once its pool is deployed with
  shtx-circuits f270a41c's verifiers (above).
- A pool with the old verifier still lets an OTC prover spend the other leg's notes this way: swap on it with no one,
  and after a swap that did not land, spend its inputs to yourself.
- SECURITY.md lists an accepted limitation: an incoming viewing key together with an OTC pack gives the identity's
  note secret, so its holder sees every spend of that identity, though it gains no spend authority. The comments that
  said an incoming viewing key derives no nullifier key are corrected.

## `v0.3.7-arc`

2026-11-12

- A swap's leg can put a memo on the output it pays the counterparty, as a transfer puts one on a recipient's output:
  `otc.prelude` takes `memo`, in that output's commitment and sealed in its body. A swap is one proof with one memo
  class, so `otc.prelude` also takes `memoClass`, which both sides declare alike, agreed like the deadline: the class
  of the longer memo, `utxoMemoClass(bytes)` (now exported). It defaults to the leg's own memo's class. Every body of
  the swap, the output pads' included, is sealed at it, and pack refuses legs sealed at two classes, naming both.
  Change, relayer and treasury outputs carry no memo. A leg's prelude now refuses its payment when the counterparty's
  receive record refuses it (`ReceiveRuleError` MEMO_TOO_SHORT / MEMO_PREFIX), before the share leaves, not at prove
  after both legs signed; a share from a payer that skips this check is still refused at prove, by the circuit.
  Internal: `sealUtxoOutputs` takes an optional `memoClass`. Not breaking: swaps without a memo, or with one of at most
  2 bytes, still pack against an older sdk.
- The rpc pool waits for a block anvil names as past its head (`block height is N but requested was N+1`), as it does
  for the other nodes' wordings, instead of returning that refusal as the answer.
- A deposit's permit probe falls back to the plain allowance only when the token refuses it (a revert, or a result that
  is missing or does not decode; `PermitUnsupportedError`). A node that failed to answer, a rejected signature or a dead
  signer now fails the deposit with its own error rather than with `ERC20InsufficientAllowance`.
- The vendored 31337 circuit artifacts were re-copied from shtx-circuits main a6a3ef7b (source tree e3103e26), which
  rebuilt them from its documented sources. No behaviour change against the rebuild of the one-address change below: same
  bytecode, ABI and VKs, only the hash and debug fields differ. They are now f270a41c's (above).
- An `arc` preset for Arc mainnet (chain 5042), wired as `arc-testnet`: USDC (the native gas token) and EURC, the
  canonical Multicall3 and Safe v1.5.0, and free nodes measured on 2026-11-11 (Arc's gateway on two hostnames, Tenderly
  and blockdaemon). The v0.3.7-arc release baked its contracts and service URLs; its start block stays a lower bound.
  It relays straight to the relayer, with no relay-queue.

### BREAKING: an account has one shielded address on every chain and pool

`keyDerivationDomain()` takes no config and is `{ name: 'Bermuda', version: '1' }`: the account signature no longer
names `chainId` or `verifyingContract` (omitted, not zeroed, as MetaMask refuses a chainId other than the active
chain's). It is the domain psd's EIP-712 descriptor (`erc7730/eip712-Bermuda.json`) names. Replay stays bound, as
every message the account key signs names the chain and the pool.

- Every signer-derived account re-addresses once; seed-derived accounts keep their address.
- **Migration.** This sdk cannot derive the old key, the signature over the domain that named the chain and the pool:
  sweep every old address, on every chain it holds funds on, to the new one with the previous sdk.
- **Linkability.** A wallet has one shielded address on every chain: whoever learns it on one chain (a payer, an
  address link, which names one chain but carries the whole address) knows it on every other. And one key-derivation
  signature is the account everywhere: a wallet that signs the `KeyDerivation` prompt for a phishing page gives away its
  account on every chain, not one.
- A burner key names its chain and pool, `bermuda:burner-account:<chainId>:<pool>:<id>:v1`, so one id is another burner
  on every chain and pool, and a burner key leaked on one chain spends nothing on another. Every burner moves once, a
  seed-derived account's too: sweep what an old burner still holds with the previous sdk.
- A recovery Safe is sealed in the address, so it must sit at one address on every chain the account uses (a CREATE2
  deploy with the same owners and salt). `account()` checks its code on the configured chain only: on a chain where the
  Safe is missing, nothing approves a recovery of the account's funds there, and where other code sits at its address,
  whoever controls that code approves them.
- What the sdk stores names its chain, and its pool where it is the pool's, whatever the `storagePrefix`: the UTXO
  cache's id and seal, the chain sync's rows and watermarks, and the queued operations it remembers. A config without a
  `storagePrefix` is given `bermuda:<chainId>:<pool>`, for a pool given as a Contract too. `utxoCacheId`,
  `sealUtxoCache` and `openUtxoCache` take the chain and pool (`{ chainId, pool }`, a config) after the viewer root.
  Every cache and sync rebuilds once.
- A Safe-linked account too: `computeAccountId(registry, subject)` drops the chain id, as the circuits and the
  registry do, so one Safe under one registry address (CREATE3, pool `DeployAccountRegistry`) is one D everywhere.
  `accountIdOf` keeps its `chainId` parameter, deprecated and ignored.
- **One D per registry deployment, never shared by testnet and mainnet.** The registry's address is its deployer's
  CREATE3 address under `ACCOUNT_REGISTRY_VERSION` (default `v1`), so a Safe's D follows the deployer key and the
  version. A release that redeploys the registry names a new version, the same on all its chains; testnets and
  mainnets name different versions, or deploy from different keys, so they never share a registry address, an account
  id or a D. On a chain the registry is not deployed on yet, the deployer key decides what code takes its address.
- `meterBase(accountId, r, pool, chainId)` takes the chain, which the account id no longer carries, so an account's
  meters, and their public start nullifiers, stay each chain's.
- The vendored 31337 circuits are rebuilt from these sources. The testenv preset names the registry's CREATE3 address;
  every other contract is where it was, as the registry's CREATE3 call takes the deployer nonce its plain CREATE took
  and another key puts the Create3Deployer in place.

### BREAKING: every issuer request is version 1

No issuer service runs on a mainnet yet, so `/assign` and `/sign` name `v: 1`, as `/key` and `/claw-keys` do
(`IIssuerAssignRequest`, `IIssuerSignRequest`); their bodies are unchanged. An issuer refuses a request of any other
version. A body of an earlier format that names version 1 too is refused by its shape, never read as the current one:
an `/assign` output without its key point, a `/sign` request without its `kind` or its shtx_hash preimage. No issuer
route reads another route's body.

### BREAKING: the pickled issuer policy preimage is `issuer-only-1`

Nothing has been deployed officially under an earlier format, so `issuerPolicyToJSON` stamps `version: 'issuer-only-1'`
on the preimage a Safe proposal keeps from propose to execute, and `issuerPolicyFromJSON` reads that version only, with
exactly its fields, each a decimal string. The earlier preimage that named `issuer-only-1` too (the policy witness with
its frozen bit and list roots, and the sender and output list witnesses, under `issuer`) is refused by its shape, and a
proposal kept under `issuer-only-2` by its version: propose it again.

### BREAKING: a period is an hour of chain time, and a validity window two unix times

Base went from 2 s to 200 ms blocks on 2026-10-21, which made every block-counted period and window there ten times
shorter. The pool now counts periods as `block.timestamp / PERIOD_SECONDS`, one hour on every chain, and compares a
proof's validity window, `notBefore * 2^64 + notAfter`, with `block.timestamp`. This sdk proves for such a pool only;
it needs a fresh deployment, and a build of it must not serve a pool of the block-number clock (every v0.3.x one).

- **The guard.** Before any hot proof, `readPoolClock(pool)` reads the pool's `PERIOD_SECONDS()` once per pool. A pool
  without it (the block-number clock) or on another length throws `PeriodClockMismatchError` (`pool`,
  `periodSeconds`), so nothing is proven for a period the pool counts otherwise. It replaces `readPoolPeriod`;
  `PoolClockCache` (internal) replaces `PoolPeriodCache`.
- **Periods.** `PERIOD_SECONDS` (3600n), `periodIdAt(timestamp)`, `periodStartsAt(id)` and `periodEndsAt(id)` (the
  first second of the next period, exclusive) are exported. `currentPeriodId(chain)` takes no period length: it reads
  the head block's timestamp, never `Date.now()`, and never an older period than one that provider reported (a
  failover to a lagging node cannot put a proof in a period that ended). Period ids are hours since 1970, about 498,000
  now: ids from a block-clock deployment are not portable. A meter of `L` periods meters `L` hours on the UTC hour
  (`L = 24` a UTC day). `OPEN_WINDOW_PERIODS` is a day of periods.
- **Windows.** `headTime(provider)` is the chain's time, the head block's timestamp, floored the same way.
  `checkedDeadline(provider, deadline)` replaces `timestampDeadlineToBlock`: a deadline is bound as given, the sentinel
  passes, and one in milliseconds or more than a year past the head's time is refused. A spend's exact `validity` window
  is checked the same way (`checkedWindow`): its close as a deadline, and an opening in milliseconds is refused too.
  `clampToFeeIncrease` closes a window at exactly `effectiveAt - 1`. `KEYED_DEFAULT_WINDOW_SECONDS` (3600n) and
  `KEYED_MAX_WINDOW_SECONDS` (86400n) past the head's time replace `KEYED_DEFAULT_WINDOW_BLOCKS` and
  `KEYED_MAX_WINDOW_BLOCKS`; `keyedValidity` and `waitUntilValid` take `{ provider }` and read the head's time, and
  `waitUntilValid` returns it and sleeps until the window can open. `ValidityWindowError.poolTime` replaces `poolBlock`.
  A compliance engine's window, a Safe proposal's deadline and an OTC share's `notAfter` are unix seconds.
- **Removed.** `poolBlockNumber`, `isNitroChain`, `NITRO_POOL_CLOCK_MS` and `nitroPoolHead`: a block's timestamp is its
  own on every chain, an Arbitrum Nitro chain's included, so neither clock takes a per-chain case.
- **ABIs.** The pool and the registry core declare `PERIOD_SECONDS()` (`0xd7ddd033`) in place of `PERIOD_BLOCKS()`;
  the registry's constructor takes no period length and it declares no `InvalidPeriod`.

### Margins and depths in seconds follow the chain's measured block time

- `blockTimeMs(source)` measures a chain's block time from its headers over at least 300 s: a rough pass over 256 blocks
  sizes a second pass, each split into eight segments whose median leaves out a time jump or a burst of blocks sharing a
  timestamp. It is reused 10 minutes per source and falls back to the block time listed for the chain, else a second.
  `confirmedHead(source, seconds)` is `max(finalized, latest - blocksIn(seconds))`, never above latest; a node refusing
  the `finalized` tag leaves the seconds to bound it, and 0 seconds is the head. `blocksIn(seconds, ms)` rounds up. They
  size margins and depths only, never a window or a period.
- The rpc pool's waits for a block (1, 2 and 4 blocks, 100 ms to 2 s each), how long it believes a node behind (1.5
  blocks, 300 ms to 3 s), the tip a pinned read counts as "now" within (4 s of blocks) and how long it reuses a read
  about now (a block, 500 ms to 2 s) follow `RpcPool.blockTimeMs`. That is a given `blockTimeMs`, else the block time
  listed for the chain, which `measureBlockTime` (on in `createRpcPool` for every chain but a local one) replaces with
  the chain's headers on the first head read and every 10 minutes after. `BLOCK_WAIT_MS` (internal) is gone.
- `RPC_CHAINS`: base-sepolia makes a block every 200 ms, and sepolia.base.org serves 200-block log windows (measured
  2026-11-10). Base, which has no free nodes and so no entry, counts 200 ms blocks until it is measured.
- A chain sync drops stored rows only when their watermark runs more than two minutes of the chain's blocks above the
  head (600 on base-sepolia), not 64 blocks, which one free node a few seconds behind exceeded there.

### BREAKING: a shielded address carries a checksum in its letter case

`KeyPair.formatAddress`, and so `address()`, `toString()`, `serialize()` and every address the sdk writes, spells the
hex body in its checksum case, as EIP-55 does an address: a letter is upper case where the nibble at its index of
SHAKE-256 over the lower-case body is 8 or more. Every parser of a shielded address (`KeyPair.fromAddress`,
`deserialize`, a recipient, relayer or treasury, a cached or transported UTXO's owner, an address link) reads a body in
one case as before, unchecked, and refuses any other mix of case (`Invalid shielded address checksum`): one changed
character or one flipped letter of a checksummed address is caught before a payment to it is lost.

- An address that was valid before still reads, to the same owner, in lower or upper case; one that mixed case at
  random is now refused.
- Compare shielded addresses case-insensitively, and key maps by their lower case or by owner id: `address()` no
  longer returns lower case.
- An address link signs the address in its checksum case too (below).
- The case of every character depends on the whole body, the X-Wing key included: a prefix (core and note key)
  compared across a viewer rotation changes case, so lowercase both sides.

### BREAKING: an address link is signed over the shielded address in its checksum case

A Safe's owners sign `AddressLink` typed data whose `privateAddress` is the shielded address in its checksum case, as
`KeyPair.address()` writes it, whatever case the caller passed (`addressLinkTypedData`, `links.typedData`), so one
address signs one struct. `verifyAddressLink`, and so `links.get`, rebuild it in that spelling only: a Safe link its
owners signed with an older sdk, over the lower-case address, no longer verifies and reads as no link until they sign
again.

- safe-server, safe-sdk, testenv and psd move with this version. safe-server rebuilds the same typed data to verify a
  Safe's write and on the address-link board: an older safe-server refuses a Safe link this sdk builds (401
  `LINK_SIGNATURE_INVALID`). psd compares the board hash safe-server builds with this sdk's, so its repin ships with
  the safe-server deploy, and a board opened before the deploy is opened again.
- The link text an EOA or a contract account signs is unchanged: its `shielded=` line is keccak256 of the address's
  1312 bytes, which no spelling changes, so those links verify as before.
- `links.message`, `links.typedData` and `links.publish` name and send the address in its checksum case, and
  `links.get` returns it so (`IAddressLink.shieldedAddress`). `links.get` verifies the address as served: one whose
  mixed case is not its checksum case reads as no link rather than being lowered past the check.
- The pinned typed-link hash and owner signature in `test/address-links.test.ts` change; safe-server's
  `test/address-link-vectors.test.ts` asserts the same literals.

### msgpackr-extract is pinned exactly

bb.js reaches msgpackr-extract, a native addon with an install script and a single publisher, through msgpackr's
`^3.0.2` range, so a fresh resolution took the newest 3.0.x. The root `overrides` pin it and its six
`@msgpackr-extract/*` binaries at 3.0.3, the versions the lockfile holds. Overrides bind this repository's installs
only: a consumer that resolves the sdk's tree afresh pins them in its own root.

### A balance says what it counts

`balance()` still totals every note received, by token address and symbol, and its enumeration is unchanged. Beside
the totals, under symbol keys that `Object.keys/values/entries`, spreads and JSON skip (`IBalance`):

- `awaitingClawKey(result)` (`AWAITING_CLAW_KEY`; root entry): the part of each total held in notes that await their
  claw keys, received but not spendable until their issuer releases the keys, by the same keys, 0n where none.
- `issuerSync(result)`: what each issuer-key token's issuer answered, as on a `findUtxos` result. The issuer-held notes
  of one that is `unreachable` or `refused` may be missing from its total, those it has not served on an earlier sync,
  so a wallet can tell an outage from a freeze.

### A withdrawal pays an address, never a name

`IWithdrawParams.to` and `recipients[].to` no longer advertise `${string}.eth` and `${string}.gno`: no name was ever
resolved, and one failed with a bare `BigInt` error after the UTXO scan. `resolveWithdrawPayees` refuses a payee that
is not a 0x-prefixed address before any I/O (`withdraw pays an address, not alice.eth`). An address without `0x` and an
ICAP string are refused too: `BigInt` would fail on them, or read the digits as a decimal number and pay another
address.

### An account is bound to a recovery Safe with code, or one named counterfactual

The pool opens a recovery only on the recovery Safe's ERC-1271 approval, so an account bound to an EOA, or to an
address without code, looked recoverable and was not.

- `account()`, `BermudaAccount.fromSeed`/`fromSigner` and `KeyPair.deriveAccount` refuse a `recoverySafe` without code
  on the configured chain. `account({ recoverySafeCounterfactual: true })`, or `true` as the last argument of the other
  three, binds a Safe yet to be deployed.
- The recovery Safe must answer ERC-1271 at its address on every chain where the owner holds funds: the check reads one
  chain only.
- `panicSweep` refuses a `recoverySafe` for a key that has none: a sweep keeps the guardian a key has and binds the
  fresh key to no new one.

### BREAKING: an OTC swap names its deadline

A swap without a deadline let whoever held both signed packs land it at any later block, a free option on the
counterparty's assets until the counterparty spent an input.

- `IOtcPreludeParams.deadline` is required. `otc.prelude` refuses a swap without one, or under the no-deadline
  sentinel, before reading the chain; `otc.pack` refuses shares whose window never closes (a prelude kept from before),
  so prelude again.
- A swap's deadline cannot default to a clock: the two shares would carry different timestamps, which `pack` refuses.
- Spending an input of one's own leg is the only way to cancel a pack already handed over (SECURITY.md, Known
  limitations).

### A spend deadline is unix seconds at most a year out

A deadline in milliseconds no longer signs a window that never closes. `checkedDeadline` (once
`timestampDeadlineToBlock`) refuses a deadline at or above 1e11 (milliseconds), and one more than a year past the chain
head's time; the no-deadline sentinel passes as before. Every spend deadline goes through it: transfers, withdrawals,
stealth unshields and OTC swaps.

### A claw-key pull expires by the chain head's clock

A device whose clock is 150 s or more off its issuer's no longer has every claw-key pull refused, nor the issuer
blamed for it. `/claw-keys` is unchanged.

- A pull's `expiresAt` is half `CLAW_KEY_PULL_WINDOW_SECONDS` after the chain head's timestamp, which the issuer's
  clock keeps to on a live chain (this device's when the head is unreadable). A pull the issuer refuses for its expiry,
  a 401 whose reason names it, is sent once more on this device's clock, the one a test chain warped ahead leaves the
  issuer's agreeing with.
- A spend that falls short by notes whose issuer refused every pull for its expiry throws `ClawKeyClockSkewError`
  (`token`, `withheld`; root and internal entries), not `ClawKeyWithheldError`. `clawKeysWithheld(token, awaiting)`
  picks the error for notes that await their claw keys, and is an internal entry point.

### BREAKING: the note labels are v1

No pool runs on a mainnet yet, so the note scheme keeps v1 labels: `NOTE_COMMITMENT_TAG` is
`hash_to_field("bermuda:shtx:note-commitment:v1")`, `NULLIFIER_TAG` `hash_to_field("bermuda:shtx:nullifier:v1")`, and
`issuedClawKey` hashes under the DST `bermuda:claw-key:issued:v1`. Every note domain, commitment, nullifier and issued
claw key moves. The known answers follow (`nf-kat.json`, shtx-circuits'; `claw-key-kat.json`, `utxo-kat.json` and
`shtx-kat.json`, regenerated), as do the differential oracle and the witness pins; the vendored 31337 circuits are
shtx-circuits `audit-r7-fixes`'.

### BREAKING: `/sign` claims each keyed input with its nullifier key

An issuer keeps the outputs of a `/sign` request, and signs it, only for a spend of a note it issued, still unspent,
whose spender holds its key. The request names each keyed input of its lane (`spends`), signed with the input's
nullifier key over the receipt it asks for; a keyless input (a note from before its token's issuer key) and a padding
input are never named.

- `/sign` carries, additively, `spends: [{ at, commitment, signature }]` after `outputs`, by ascending `at`: one per
  input of the lane's token id that carries value and a claw commitment, `at` its nullifier's position in
  `transaction.nullifiers`, `commitment` 0x-hex32, `signature` the 96-byte Grumpkin Schnorr signature by the input's
  nullifier key under the domain `bermuda:issuer:spend:schnorr:v1` (`ISSUER_SPEND_DOMAIN_FIELD`) over
  `issuerSpendMessage({ receiptMessage, commitment, nullifier })` = `Poseidon2(receiptMessage, commitment,
transaction.nullifiers[at])`, `receiptMessage` the `issuerReceiptMessage` the request asks for: its kind, the
  shtx_hash over the issuer's own chain and pool, the sender, the lane token, the lane's outputs hash and the
  issuer-held flag. Absent when the lane spends no keyed note (a deposit). An issuer takes the key point from its own
  record of `commitment`, never from the request, checks that the record's nullifier is `transaction.nullifiers[at]`
  and that the record is confirmed and unspent, and verifies the signature (`verifyIssuerSpend`). Each signing draws
  its own nonce: a restated request carries other signatures over the same messages.
- `laneInputsOf(inputs, nullifiers, laneToken)`, `issuerSpendMessage`, `signIssuerSpend`, `verifyIssuerSpend` and the
  types `ILaneInput`, `IIssuerSpend` and `IIssuerSignSpend` are internal entry points. `issuerSignRequest` takes
  `laneInputs`, `requestLaneReceipt` requires them, and `requestIssuerReceipts` requires the proof's `inputs`, padding
  included.

### BREAKING: the payee pulls its claw keys

A payer no longer learns a keyed note's claw key `c`, so neither it nor a Safe deposit's co-signers compute the
payee's nullifier. The issuer derives `c` from its seed and the note's key point alone, `hash_to_field(issuerSeed ‖
chainId ‖ pool ‖ token ‖ P.x ‖ P.y, DST 'bermuda:claw-key:issued:v1')` (`issuedClawKey(seed, { chainId, pool, token,
keyPoint })`, `test/fixtures/claw-key-kat.json` regenerated), and releases it only to the holder of the note's
nullifier key.

- `/assign` takes each output's key point, `{ outputs: [{ keyX, keyY }] }`, and answers `{ clawCommitments }`
  (`assignClawCommitments`, replacing `assignClawKeys`). `keyOutputs` sets each keyed output's claw commitment, no
  claw key.
- `/claw-keys` v1, `{ chainId, pool, expiresAt, items: [{ token, keyX, keyY, signature }] }` → `{ clawKeys }`: each
  item a Grumpkin Schnorr signature by the note's nullifier key over
  `Poseidon2(chainId, pool, token, P.x, P.y, expiresAt)` under the domain `bermuda:claw-key:pull:v1`
  (`CLAW_KEY_PULL_DOMAIN_FIELD`), the expiry at most `CLAW_KEY_PULL_WINDOW_SECONDS` (300) ahead, at most
  `MAX_CLAW_KEY_PULL_ITEMS` (64) items. `clawKeyPullMessage`, `signClawKeyPull`, `verifyClawKeyPull`,
  `fetchClawKeys` and `pullClawKeys` are internal entry points.
- The note plaintext carries the claw commitment where it carried the claw key (same size, 624 B at class 0). A
  received keyed note awaits its claw key (`Utxo.awaitsClawKey`) until `findUtxos` pulls it, batched per token, and
  checks that it opens the claw commitment (`Utxo.setClawKey`); the cache keeps it. An awaiting note counts in the
  balance but is neither told spent nor selected: a spend it would have covered throws `ClawKeyWithheldError` (root
  entry), and a spend pulls its inputs' claw keys again before proving. The device pulls its own outputs' like any
  other.
- `setKey` takes a `clawCommitment`, or a `clawKey`, or both, beside any key form. `paysAddress` and `acceptPayment`
  require a claw commitment exactly in a keyed token and no claw key.
- Deposit reveals (`depositOutputOpenings`, and with them a stealth reshield's) carry each output's `tweak` beside its
  key point and claw commitment, never a claw key: a co-signer seals a third party's output again from them.
  `depositOutputOpenings` and `ClawKeyWithheldError` are internal entry points too.

### Wire and API changes of the audit fixes

- `/sign` carries, additively, `deposit: { depositId, attestation }` on a deposit (the compliance engine's
  96-byte signature over Poseidon2(chainId, pool, token id, publicAmount, depositId, Poseidon2(commitments),
  depositor, validity), the circuit's `deposit_attestation_hash`) and `withdrawal: { payees?, extData }` on a withdrawal (the ext data without its meter ciphertexts,
  hashing to `transaction.extDataHash`, and for a standard one the payee split `transaction.recipient` digests). The
  wire spec now says that `transaction.recipient` is a payee digest on a standard withdrawal.
- The bundled pool and PoolConfig ABIs are regenerated from the pool (`scripts/sync-abis.mjs`): PoolConfig's keeper
  (`keeper()`, `isKeeper(account)`, true for the governor, the pauser and the keeper, `setKeeper(newKeeper)`,
  `KeeperUpdated(previousKeeper, newKeeper)`, and the constructor's `initialKeeper`), and the pool's
  `ClassIndexRootFloorDue(floor)`, the class-index root floor a keeper's `accrue` raises.
- A deposit's artifacts carry the compliance attestation its keyed lanes' issuers were shown
  (`ITransactArtifacts.depositAttestation`), and its reveal (`IDepositReveal`, an internal type) the attestation
  beside the openings, so a Safe deposit's co-owner restating it at `/sign` shows the issuer what the proposer did.
- `sdk.panicSweep(params, { relayer, relayFees })`: the relay fee is taken per token and class
  (`relayFees[token] = { idle?, vaulted? }`, underlying units) instead of one `relayFee`, and a class with nothing to
  sweep is reported in `errors`.
- `sdk.inbound.bindNotice({ owner })` tells before a first binding that it publicly links the shielded address to its
  writer; null for an owner that has a record.
- Transfer and withdrawal plans carry `abandonNotice` while a vaulted class's abandon is on notice, idle value then
  pays first, and an amount in underlying units is paid or withdrawn from the class, at its buffer-only index, only
  with `options.acceptAbandonNotice` (`ITransferOptions`, `IWithdrawOptions`); otherwise the plan is refused, and
  share counts (`units: 'shares'`) are taken as given. Anyone's `rebalance(token)` drains the venue into the buffer
  during the notice, which lifts that index back towards the class's value. Transfer plans carry `converted` and
  `conversionIndex` for the payees the AUTOVAULT mandate converts; `TransferRecipient` and `TransferTxDetails` carry
  `vaulted` and `index`.
- `findDoxWithdrawalRequests` and the chain sync follow `DoxWithdrawalRedirected` (the withdrawals family has a third
  event: an indexer must serve it). A synced bytes field longer than its format's longest is dropped, a leaf's
  commitment kept: a leaf's ciphertext at most a full header and the widest body (18,816 B), a sealed policy list a
  full one (`accountPolicy.MAX_SEALED_LIST_LENGTH`, 2,123 B, the registry's `MAX_SEALED_LIST_BYTES`), a memo prefix
  256 B.
- `readVaultIndex` refuses an index that does not match the class's assets per share.
- The bundled ABIs follow the audit-fixed pool and registry. The dox withdrawal events name the class:
  `DoxWithdrawalProven(recipient, token, isVaulted, depositIds, withdrawnAmounts)` and
  `DoxWithdrawalRequested(requestId, recipient, token, isVaulted, amount, releasableAt, unwrap)`, whose topic0 is now
  `0x9b06655e…7f19` (an indexer serves it); `IDoxWithdrawalRequest.vaulted` carries it, the amount in the token's
  units either way. `recoverySessions` returns ten fields, `openedAt` last; past its deadline anyone closes a session
  with `cancelRecovery(sessionId, 0x)`, which emits `RecoveryClosed(sessionId)`, and a late submit reverts
  `RecoveryExpired`. `InboundPolicies.closeRetiredRecords(accountId)` closes the receive records of identities an
  account no longer spends: batch it with every retire and rotate. New errors: `SealedListTooLong`,
  `IdentityRotationPending`, `PreviousIdentityUnretired` (SafeAccounts), `InvalidShieldedAddress` (PoolConfig);
  `explainPoolError` and `explainRegistryError` hint at them and at `UnauthorizedIssuer` (a new issuer leaf needs a
  vetted token or an open tree with a nonzero update fee) and `InvalidEncryptedOutputs` (a ciphertext off its
  format's length).
- `PausableOperation` gains `issuerPolicyUpdate`, which every pause level above none refuses, as the pool does.
- A withdrawal's change is accepted at a spending account's current D as well, as the withdraw circuits take it.
- A transact or a swap leg is refused before proving while PoolConfig names no shielded treasury: the pool takes no
  transact without one.
- The pool keys the redeposit credit by payee and token, so a stealth reshield's claim is backed by an unshield proven
  in steps through the multicall, and by a Safe batch's payout; a stated index's margin on a deposit, conversion or
  release becomes Bermuda's fee shares instead of moving the class index.

### BREAKING: identity-bound note keys

Every note's nullifier key is bound to its owner in-circuit. An identity has a note secret `r` (from its viewer root
and its core) and publishes `R = r·G`; its owner commitment is `Poseidon2(OWNER_TAG, core, R.x, R.y)`, a single key's
core `Poseidon2(KEY_CORE_TAG, Poseidon2(pk.x, pk.y), recoveryHash)`, an account identity's `Poseidon2(ACCOUNT_CORE_TAG,
Poseidon2(accountId, dr), recoveryHash)`. A payer draws a tweak `t` per output and the note commits to `P = t·R`
(arity 11: `…, rho, P.x, P.y, ck`); the owner derives `nk = t·r mod q`. A keyed token's issuer derives every output of
its lane a claw key `c` (`ck = Poseidon2(CLAW_KEY_TAG, c)`, 0 on a keyless lane), and a note's nullifier is
`Poseidon2(NULLIFIER_TAG, s, cm)`, `s = c` on a keyed note and `nk` otherwise. The 31337 artifacts are shtx-circuits
`audit-r6-fixes`'; they drop the dox pad, recover's public amount, recipient and deltas, and clawback's chain id.

- Address: `0x ‖ core ‖ R.x ‖ R.y ‖ X-Wing key`, 1312 bytes (`ADDRESS_HEX_LENGTH` 2624); `formatAddress`, `fromParts`
  and `accountShieldedAddress` take `(core, noteKey, viewer)`; `KeyPair.core`, `noteKey`, `noteSecret`,
  `KeyPair.fromNoteSecret` (an account identity), `KeyPair.ofOwnerId` (a stand-in). `IShieldedOwner` loses `nkc` and
  gains `core`, `noteKey` and `noteSecret`; `AccountIdentity`, `readAccountState` and `accountBindingInputs` take the
  identity's `noteKey`; `computeDestination` takes it, `computeAccountCore` and `accountCoreOf` are new. The incoming
  viewing key is `{ incomingViewingKey, core, noteKeyX, noteKeyY }`.
- `nullifier.ts`: `computeKeyCore`, `computeOwner`, `noteSecret`, `noteKeyOf`, `keyPoint`, `keyPointOfNk`,
  `nullifierKey`, `selfTweak`, `randomTweak`, `clawCommitment`, `issuedClawKey` (`test/fixtures/claw-key-kat.json`,
  which issuer-sdk copies); `nkCommitment`, `nkRoot`, `nkAddr`, `noteKey`,
  `opensNkc`, `issuedNullifierKey` and `computeOwnerId` are gone.
- `Utxo`: `keyPoint`, `tweak`, `clawCommitment`, `clawKey`, `nk` and `selfProved` replace `nkc`, `nkKind`, `twin`;
  `setKey({ tweak | nk | keyPoint })`, `deriveNk(r)`; `trackable` is a keyed note, `delegable` a note this device
  proved. The plaintext is `core ‖ R ‖ token ‖ blinding ‖ rho ‖ tweak ‖ clawCommitment ‖ ids ‖ amounts ‖ memo` (624 B at
  class 0, bodies 640 + 32c B, `UTXO_MAX_DETACHED_LENGTH` 2,016 B): the pool's `UTXO_BODY_BYTES` follows.
- Issuer: `/sign` rows are 33 fields, the key point at [30..31] and the claw commitment at [32], never a tweak or a
  nullifier key; the `/utxos` keys mode, `fetchIssuedKeys`, `IIssuerUtxoItem.nk`, the cache's pending notes and
  `IIssuerSyncStatus.unresolved`, `foreign` and `fault` are gone. `paysAddress` and `acceptPayment` drop the relay.
- A swap spends only notes this device proved (their tweak is its self tweak); a payment or another swap's change is
  refreshed by a transfer to oneself first. OTC shares and packs carry `spenderNoteKey`.
- Witnesses: `SpendAuth.note_keys_x/y`, `SpendKey.note_key_x/y`, the account witness's `note_key_x/y` and
  `current_note_key_x/y`, policy_update's `Binding.note_key_x/y`; `inputNotesWitness`, `outputNotesWitness` and
  `clawbackNotesWitness` are internal entry points.
- Deposit reveals and recovery openings carry the key point and the claw commitment instead of `nkc`, a deposit
  reveal the tweak too.

### BREAKING: governor-replaceable verifiers

The bundled ABIs follow the pool's replaceable verifiers (pool#298). The governor schedules one shape's verifier with
its build manifest's hash, applies it after `VERIFIER_DELAY_SECONDS` (7 days) and freezes it for good, one verifier
per call: `setVerifier(circuit, publicInputsLength, verifier, manifestHash)`, `applyVerifier` and
`freezeVerifier(circuit, publicInputsLength)`, announced by `VerifierScheduled`, `VerifierSet` and `VerifierFrozen`
with the shape indexed. The registry's core holds the one policy_update verifier the same way (`setVerifier(verifier,
manifestHash)`, `applyVerifier()`, `freezeVerifier()`, `pendingVerifier()`, `isVerifierFrozen()`); `wire` takes it as
a third argument, and the modules no longer carry `POLICY_UPDATE_VERIFIER()`.

- The pool links one more library, `VerifierLib`, created before it, so every later address moves by one nonce:
  `testenv` (pool, multiSendCallOnly, batchDelegate, multiSend, signMsgHashLib) and `eez-rollup-x` (pool at 33,
  multiCall at 34, batchDelegate at 35).

### BREAKING: recipient-held nullifier keys

The nullifier redesign of sdk#835. A note commits to `nkc = Poseidon2(NK_COMMITMENT_TAG, nk)` for a nullifier key
only its recipient side holds, under its pool's domain `dom = Poseidon2(NOTE_COMMITMENT_TAG, chainId, pool)`, and is
spent with `nf = Poseidon2(NULLIFIER_TAG, nk, blinding, cm)`: its payer can neither compute nor recognise the spend,
a note has one nullifier, and every output's `rho` is one of its proof's input nullifiers, so no two leaves of a pool
are equal. It replaces the sender-chosen nullifier secret outright; nothing reads the old scheme, and the new SDK
works with the redeployed pools only (shtx-circuits `nullifier-keys-final`, whose 31337 artifacts are vendored here).

- `nullifier.ts`: `noteDomain`, `nkCommitment`, `noteNullifier`, `xwingSeed`, `nkRoot`, `nkAddr`, `noteKey`,
  `issuedNullifierKey` (internal entry point). `test/fixtures/nf-kat.json` is shtx-circuits' own;
  `test/fixtures/issued-nk-kat.json` (`scripts/gen-issued-nk-kat.mjs`) is copied by issuer-sdk.
- Keys: `KeyPair.viewerRoot` (the full viewing key) is explicit; the X-Wing viewer pair comes from
  `xwingSeed(viewerRoot)` (the incoming viewing key, `serialize('incoming-viewing-key')` →
  `{ incomingViewingKey, ownerId, nkc }`), and `KeyPair.nkc` commits to the address key. `IShieldedOwner` gains
  `viewerRoot`, `previousViewerRoots` and `nkc`; the UTXO cache and the recovery salt read `viewerRoot`.
- Address: `0x ‖ ownerId ‖ nkc ‖ X-Wing key`, 1280 bytes (`ADDRESS_HEX_LENGTH` 2560); `formatAddress`, `fromParts`
  and `accountShieldedAddress` take `nkc`. A 2496-hex address no longer parses.
- `Utxo`: `rho`, `nkc` and an optional `nk` (`setRho`, `setKey`, `setNoteKey`) replace `nullifierSecret`, and it
  takes its `pool`. `getCommitment()` throws until `rho` and `nkc` are set, `getNullifier()` without `nk`. The
  plaintext carries `rho` at 84 and `nkc` at 116 (528 B at class 0, bodies 544 + 32c B, `UTXO_MAX_DETACHED_LENGTH`
  1,920 B) and never `nk`; the decoder refuses a `blinding`, `rho` or `nkc` outside the field and a zero `blinding`.
- Key rounds: a transact (deposits included), an OTC leg and every pad set `rho` and then each output's `nkc`
  (`keyOutputs`): own outputs and pads take their note key, keyless payments the payee's address key, and in a
  token with a live issuer key every valued output its sender does not own takes the key its issuer assigns
  (`/assign`, `assignIssuerKeys`). A zero-amount output to a third party is refused. Deposits take `self`.
- Issuer client: `IssuerRoute` `'/assign'`; `/sign` rows of 31 fields with `rho` at [2] and `nk` at [30] (the note
  key of the sender's own outputs and pads, 0 elsewhere); `fetchIssuedKeys` (keys mode, 128 a call);
  `IIssuerUtxoItem.nk`; `paysAddress` and `acceptPayment`, which the OTC buyer check now runs.
- Opening: a note counts only when a key opens its `nkc` (the address or note key of the viewer generation that
  opened it, or a pulled issued key); otherwise it is foreign, or unresolved and retried each scan
  (`IIssuerSyncStatus.unresolved`, `foreign`, `fault`). Counted notes carry `trackable` and `twin`, and
  `delegable` (no address key, no twin), which an OTC pack requires of its inputs.
- Spent detection reads whole NullifierSpent families only: `isSpentOf`, the on-chain confirmation of listed
  nullifiers and `config.isSpentConcurrency` are gone. The pre-proof check of picked inputs re-reads, over RPC, the
  spends from the earliest input's leaf to the last block the indexer served (`ChainSync.checkSpent`, `spentInputs`);
  it persists the checked range and fails closed.
- The meter base binds the pool (`meterBase(accountId, r_cur, pool)`); the receipt and account-policy tags are v1
  (`bermuda:receipt:v1`, `bermuda:recovery-receipt:v1`, `bermuda:shtx:account-policy:v1`).

### Safe output ciphertext validation

Prepared operations retain private `outputEncryption` evidence in circuit order. Slot evidence carries the
fresh X-Wing encapsulation seeds and the detached envelope; no owner viewer seed is exported. The internal
`assertOutputEncryption` replays recipient encryption or opens own outputs, checking the actual on-chain
header/body and the verified note commitment. Safe deposits expose the matching evidence only through
the opt-in `_revealOutputs` path. Keep this evidence inside encrypted proposals, never in calldata or logs.

### Fewer reads one after another in a deposit and a proof

Reads that take nothing from each other's answers are now made in one round instead of one after another; what
is read, proven, signed and sent is unchanged.

- `deposit`: the pool's deposit-fee rate, the recipients' sender lists, the deposit class (`depositClassFor`) and
  the issuer-token lookup.
- A deposit or transfer proof (`getTransactProof`): the pause check, the registry bindings, the deposit-id
  exclusion proofs (`/blacklist`) and, without a granted rate, the compliance gateway's key.
- A withdrawal proof: the pause check and the registry bindings.

### Spent checks in one Multicall3 call

A balance read confirms each UTXO the synced spent set lists, and a spend confirms its inputs, with `pool.isSpent`.
Where the chain has a Multicall3 (`config.multiCall`), they are now one `aggregate3` call (per 256 nullifiers)
instead of one call each, so k checks wait one round trip instead of k. Without a Multicall3, or when it cannot
answer, they are asked one by one as before (`config.isSpentConcurrency` still sets how many at once).

### `config.proverSrsSize`: the CRS the WASM prover loads

`proverSrsSize` is handed to bb.js as `srsSize`, the number of G1 points `Barretenberg.new` downloads and loads.
Unset keeps bb.js's default (2^19, 2^18 on iOS). Every circuit the SDK proves is at most 2^18 gates
(shtx-circuits scripts/gates.json), so a browser app can set 2^18 to halve the CRS download and the memory the
prover holds. A native bb prover ignores it.

### `KeyPair.fromAddress` takes only the canonical spelling

`fromAddress` (and every call that reads a shielded address through it) now accepts only `SHIELDED_ADDRESS_PATTERN`:
`0x` and the 2496 hex characters, any case. It no longer strips the first `0x` wherever it stands or lets `BigInt`
trim whitespace in the owner field, so one key has one accepted spelling. Found by the property fuzzing of sdk#825.

### The circuit artifacts after shtx-circuits' crate layout change

The vendored 31337 circuit artifacts are re-copied from shtx-circuits main after its crate layout change
(shtx-circuits#216); no behaviour change: same bytecode, ABI and VKs, only the hash and debug fields differ.

### BREAKING: the UTXO cache is sealed under the viewer root

Fixes finding SEC-006. `findUtxos` kept every cached UTXO's opening (blinding, nullifier secret,
deposit ids, nullifier) as plain JSON under `<storagePrefix>:utxos:<address>`, and handed it to anyone
who asked with the address alone (`KeyPair.fromAddress`). It also took a cached commitment, nullifier
and decrypt watermark as given, so whoever could write the storage could show UTXOs that are not
there, or hide real ones. Now:

- Each owner's cache is sealed with XChaCha20-Poly1305 under
  `HKDF-SHA256(viewerRoot, 'bermuda:utxo-cache:v1')`, the full storage key its AAD, and stored under
  an id that another HKDF of the viewer root derives, not under the address. An entry that does not
  open is dropped, and the next scan decrypts every leaf again.
- `findUtxos` (and with it `findUtxosUpTo` and `balance`) and `ingestIssuerUtxos` throw
  `<caller>: the viewing secret is required` for an owner without a non-zero 32-byte viewer secret
  (`xwing.secretKey`), before asking the chain anything.
- Reading a cached UTXO, or one in the OTC JSON form (`utxoFromJSON`), refuses a stored `_commitment`
  or `_nullifier` that is not its opening's; the cache's watermark and block are checked too.
- `fileSystemStorage`, behind `config.utxoCache` and `config.commitmentEventsCache`, writes a sibling
  file with mode 0o600 and renames it over the store, so `config.fs` must provide `renameSync`
  (`node:fs` does).
- The cache module (`initCache`) no longer has a `'utxos'` type: nothing used it, and it wrote the
  cache in clear.

Migrate:

- **first scan:** an owner's first scan deletes its plaintext entry and decrypts every leaf again;
  so does a Safe-linked account's first scan after a viewer rotation. Issuer-only tokens the chain's
  `issuerTokens` does not list are synced again once named in `tokens` or `config.issuerTokens`.
- **custom `fs`:** add `renameSync`.
- **read-only owners:** pass the owner with its viewer secret; a viewing-key keypair
  (`KeyPair.deserialize(viewingKey)`) has it.

### A sponsored stealth bundle estimates its minGas without signing an `Execute`

To find its `minGas`, a sponsored stealth bundle signed a complete `executeWithAuth` with
`minGas = 0`, at the burner's live nonce and real deadline, and sent it to the RPC in
`eth_estimateGas`. Whoever saw that request could send the call first with a gas limit that starves
it, which BatchDelegate's gas floor exists to refuse, and the relayer's call then reverted
`InvalidNonce`. `burnerMinGas` now estimates the burner's own `execute` of the batch, from the
burner, which only the burner can send. It adds `BURNER_AUTH_OVERHEAD_GAS` (30,000) for what
`executeWithAuth` spends beyond `execute`, then the 20% margin as before. A fresh burner's estimate
carries its EIP-7702 delegation signed for the nonce after its current one, because the sender's
nonce goes up before its authorizations apply.

### BREAKING: `DepositAuthorization` is `DepositRelayAuthorization`

The EIP-712 type a depositor signs for a deposit someone else sends (a relayer) is now
`DepositRelayAuthorization`, as in pool#335. Its fields, domain and use are unchanged, but its name
is part of the typehash, so a signature verifies only against a pool with pool#335. The names follow:

- `DEPOSIT_AUTHORIZATION_TYPES` is `DEPOSIT_RELAY_AUTHORIZATION_TYPES`, keyed `DepositRelayAuthorization`.
- `depositAuthorizationOf`, `depositAuthorizationTypedData` and `depositAuthorizationDigest` are
  `depositRelayAuthorizationOf`, `depositRelayAuthorizationTypedData` and `depositRelayAuthorizationDigest`.
- `IDepositAuthorization` and `IDepositAuthorizationExtData` are `IDepositRelayAuthorization` and
  `IDepositRelayAuthorizationExtData`.
- The pool error `InvalidDepositAuthorization` is `InvalidDepositRelayAuthorization` (selector
  `0xd192911e`), in the bundled pool ABI and in `POOL_ERROR_HINTS`.

Migrate:

- **pool:** a pool with pool#335.
- **imports:** the names above; there are no aliases.
- **wallet descriptors** (ERC-7730) and anything else that names the EIP-712 type: `DepositRelayAuthorization`.

### BREAKING: circuits that enforce their own public-input checks

The sdk side of fv#39. `src/circuits/31337/` vendors the `artifacts/31337` of shtx-circuits main
0f09a283 (shtx-circuits#214), and the bundled pool ABI follows pool main 81cbf534 (pool#333). The
circuits now prove what the pool checked of their public inputs, and the pool drops those checks: a
clawback's active nullifiers are not 0 and are distinct, a lane that flips has a token, a standard
withdrawal's extra payees are addresses and its padding a suffix of zero amounts, an active meter slot
publishes a nullifier and a note that are not 0, the leaves a proof inserts (its outputs and its meter
notes) are distinct, and a recovery pays no public recipient and names a recovery Safe that is an
address. They also bound each spent amount below 2^248 and a withdrawal's public outflow below 2^250.
Ten verifying keys change (all but `policy_update_16`), so this SDK proves only to a pool deployed with
their verifiers. Inputs and public inputs are unchanged.

- `buildWithdrawPayoutSplit` refuses a payee that is not an address before anyone signs, and
  `computeRecoveryBinding` a recovery Safe that is not one, which would make the owner unrecoverable.
- The `InvalidMeterSlot` hint is gone, and `InvalidClawbackChainId`, `DuplicateNullifier`,
  `DuplicateCommitment` and `InvalidMeterSlot` leave the bundled pool ABI.
- The vendored artifacts name `nargo 1.0.0` in `noir_version`.

Migrate:

- **pool:** pool 81cbf534 (pool#333), with the verifiers of shtx-circuits 0f09a283.
- **every chain's `artifacts` URL:** that chain's artifacts of shtx-circuits 0f09a283.
- **testenv:** shtx-circuits 0f09a283, pool 81cbf534 and this release.

## `v0.3.6-x`

2026-10-31

### BREAKING: `eez-rollup-x` is rollupX, chain 696991

The `eez-rollup-x` preset moves from EEZ-X (chain 696990, EEZ rollup id 1) to EEZ's new rollupX
(chain 696991, rollup id 2), for the v0.3.6-x release. Its reads go through
`https://rollupx.eez.dev/rpc/l2` (100,000-block log windows, 2 s blocks, no CORS, and no
`debug_traceTransaction`), wallets send cross-chain calls to `https://rollupx.eez.dev/composer/l2`
and `/l1`, and its services sit under `/bermuda/v0.3.6-x`. The bridged USDC is
`0xB7b78C5993c2C55f1604Fdc1b57AF14FDC853a56`. The layout addresses stay, since the same deployer
creates them at the same nonces; `startBlock` is a lower bound until release.sh bakes the deploy
block. `chainIdToName`, `tokenList` and the RPC table now know 696991, not 696990. The v0.3.5-x
deployment on 696990 keeps the v0.3.5-x sdk.

### Noir 1.0.0

`@noir-lang/noir_js` moves from `1.0.0-rc.6` to `1.0.0`, and with it `acvm_js`, `noirc_abi` and
`types`. `nargo 1.0.0` compiles the circuits to the same bytecode, ABI and hash as `nargo 1.0.0-rc.6`,
so the vendored artifacts, the witnesses, the proofs and the verifiers are unchanged.
`@aztec-foundation/bb.js` stays `6.0.0`.

### `relay` resolves only on the transaction it submitted

`relay` resolved with whatever hash a relayer, or a relay-queue result, reported, and a payload
that carries a re-prove resolved once that hash landed with status 1. A dishonest relayer, or
anyone who can write a queue result, could report the hash of an unrelated successful transaction,
so the user was told a deposit or withdrawal ran that never did. `relay` now waits for the
reported transaction to land (`wait`), looks it up on its own provider and throws unless its
target, calldata, value and EIP-7702 authorizations are those submitted, for every request of a
batch. Every relay now resolves once its transaction landed, not once it was broadcast.
A batch sent straight to a relayer now resolves with its last hash; it used to resolve with
`undefined`, because the relayer answers a batch with `txs`.

### A panic sweep plans only batches it can prove, and one token's failure no longer stops the rest

`planPanicSweep` filtered UTXOs by class and amount only. A UTXO carrying a flagged deposit id
joined a batch whose proof then failed `key is already present` (transact proves every deposit id
it spends absent from the blocklist), and a batch could carry more than the proof's 16 deposit ids
(`Too many deposit ids`). Either failure rejected the whole sweep, so no token got a payload. The
planner now leaves flagged UTXOs out and shrinks a batch to 16 deposit ids. `sdk.panicSweep`
sweeps each token and class on its own and returns `errors` (token, class, error) next to the
`sweeps` it built, so check `errors` rather than rely on a throw. A blocklist it cannot fetch now
fails the sweep instead of reading as empty (`requireComplianceBlackList`).

### A cached UTXO the chain does not hold is dropped, not picked first

A UTXO left the cache only once spent. One from a reorged-out payment, a forged
`CommitmentInserted` log from one node or a stale cached `eth_getLogs` stayed in the balance for
good, and largest-first picked it first, so every proof failed `MerkleForest: commitment … not
found`. `findUtxos` now drops a cached UTXO whose `index:commitment` the synced leaves lack, and
then decrypts every leaf again, once: its watermark was moved over leaves the chain no longer holds.
`findUtxosUpTo` looks the picked inputs up among the root-checked leaves and picks again without
those the chain lacks.

## `v0.3.5-x`

2026-10-29

### A stealth bundle whose period ends before its minGas estimate is proven again

A sponsored stealth bundle signs a minGas that is the estimate of the whole relayed call, its fresh
leg proofs included (pool#305). When the pool's period ended between proving the legs and that
estimate, the estimate reverted `StalePeriod` and `stealth()` threw. The legs are now proven again
and the bundle assembled again within `proveWithinPeriod`'s bound, with the same signatures,
vouchers and relay fee; a re-prove at relay time does the same. Any other refusal still throws.

### A revert never takes a method off the RPC pool

`classify` reads an EVM revert (code 3, or "execution reverted") as the contract's answer before
any text rule. A revert reason naming "method not supported" or "not whitelisted" marked the method
unsupported on every node for good, so anyone who could make a node run their contract (an
ERC-1271 check, say) could stop every later `eth_call` until a restart.

### BREAKING: a vaulted withdrawal states 5 bps above the exact index

`statedWithdrawIndex(exact)` is `ceil(exact * (1 + 5 bps))`, not 1 bps above it. pool#318 takes a
vaulted withdrawal within `exact <= idx <= exact * (1 + EXIT_WINDOW_BPS)`, with `EXIT_WINDOW_BPS = 10`
(exported, with `inExitWindow`), so one in flight over a write-down reverts instead of paying out at
the written-down index. 5 bps is the middle of that window: the index lands through a rise or a drop
of about 5 bps before inclusion. At proving, a vaulted withdrawal keeps its prepared index while
the window takes it and states it again once the class left the window either way (before, only
once it rose past it). That charges its capped payees otherwise, so their owners approve again; its
signed `minOut` still bounds what a drop pays.

### A released payment is paid at least its amount

With pool#318, a vaulted transfer sizes a payment the AUTOVAULT mandate releases (its recipient's
record refuses vaulted value, and it is not the spender) at the release's stated index,
`ceil(amount * RAY / statedReleaseIndex(index))`, not at the fresh index, where it was paid about
1 bps short. The payer bears the margin. `ITransferPlan.released` names those payees, the recipients'
then the relayer's, so `buildTransferPlanPayload` converts the amounts again as planned.

The circuit prices each deposit id of a release on its own, `floor(c * index / RAY)`, so a payment
carrying several lost up to a unit on each. `applyMandate` now pays a released payment of `x` shares
at least `floor(x * index / RAY)` units, their worth as one part, topping it up with shares from the
spender's change. Each proof of a chunked payment rounds on its own, and an index lower at proving
than at planning prices it lower.

### BREAKING: the registry ABIs follow pool#318

- `setVaultExemption(accountId, until, sequence, deadline, signature)` (0xd6b22839, was 0x3a434063)
  and `vaultExemptionDigest(accountId, until, sequence, deadline)`: the compliance gateway updater
  signs `VaultExemption(uint256 accountId,uint64 until,uint64 seq,uint256 deadline)`, refused after
  `deadline` (compliance-engine#174 signs it). The SDK never submits one.
- InboundPolicies takes a binding's `predecessor` as a hint and walks from it: `NotPredecessor` is
  gone, and so is its hint in `REGISTRY_ERROR_HINTS`. `onVaultExemption`'s flag is `wasGranted`.

Migrate: safe-sdk (a vaulted withdrawal's window), testenv (exemption signatures with a deadline,
vaulted withdrawals in flight over a write-down).

### BREAKING: a release states 1 bps below the fresh index

`releaseIndex` states `statedReleaseIndex(indexNow)`, `floor(indexNow * (1 - 1 bps))`, not the fresh
index. pool#318 takes a release within `fresh * (1 - RELEASE_WINDOW_BPS) <= idx <= fresh`, with
`RELEASE_WINDOW_BPS = 10` (exported), so a release lands through a drop of less than 1 bps (a venue
pull's rounding) or a rise of less than about 9 bps (yield or a venue donation) before it lands. At
the fresh index, a one-unit drop or a rise of 1 bps reverted it with `VaultIndexDrift`. A released
payment pays at most 1 bps fewer idle units, which the class's holders keep. Needs pool#318: the old
1 bps window refuses most indexes stated this way.

The bundled pool ABI declares `FundingExceedsLoss` (0x7e200d5d): `fundVaultClass` is the governor's
or the pauser's and only restores a measured loss, up to the class's reference index. The SDK never
calls it.

Migrate: safe-sdk (a release's window), testenv (funding a class as the governor or the pauser).

### BREAKING: the circuits release: signed meter ciphertexts, caps in units, the AUTOVAULT mandate

The vendored circuits are shtx-circuits#202's `artifacts/31337` (b6e23140), and the bundled pool,
registry and inbound ABIs follow pool#315 (0b905202). Every proving flow takes their layout: nine
verifying keys changed, so this SDK proves only to a pool and registry deployed from them.

- **Meters.** A meter step carries its next note's `ciphertext` (`IMeterStep`), sealed under the
  account's meter key (`planMeterSteps({ seal })`; a cover step's is 232 random bytes). The owners
  sign each real step's triple with its ciphertext's hash (`meterBinding`), each slot publishes it
  (`meterOutputsAbi`), and the period input is the plain period id (`assertPeriodId`). An account
  hands an OTC prover its next notes and their `ciphertexts` (`IAccountMeters`), never a key.
  Removed: `meterDigest`, `packPeriodInput`, `unpackPeriodInput`, `meterSealKey`,
  `sealMeterNoteTo`, `METER_ENVELOPE_LENGTH`, `meterCiphertexts`, `verifyMeterCiphertexts`,
  `IAccountMeters.sealTo` and `rebuildMeters`' `planned`.
- **Receive records carry exemptions.** The registry mirror follows `ReceiveExemptionSet`
  (`ReceiveRecord.exemptUntil`, synced by chain sync and served by the indexer), each opening's word
  carries it, and `receiveTerms(registry, owner, periodId)` reads a recipient's live exemption and
  its refusal, which binds only while it is exempt. Removed: `inbound.expireRefusal` and the
  `RefusalLive` hint.
- **The AUTOVAULT mandate** (`mandate.ts`). A transfer's own change converts unless its spender is
  exempt, a payment converts unless its recipient's record proves a live exemption, and a vaulted
  payment to a recipient refusing vaulted value is released into the idle class, at the fresh index
  (`releaseIndex`); `prepareOperation` flips the outputs (`applyMandate`, `flipOutputs` replaces
  `convertLaneChange`), carries `outReleased` beside `outConverted`, and settles each flipping lane's
  transfer fee against what the flipped payments are worth. A payment converts at its own deposit
  ids' floor, so it is worth at most what it paid. A proof checks the classes again at its root and
  period and asks for new signatures when they changed. Each OTC leg flips its outputs the same way,
  and a counterparty accepts a flipped receive UTXO worth the advertised amount at the leg's index.
  An idle deposit of a bit-on token is refused unless every recipient but the fee treasury is exempt
  (`depositMustVault`, `assertDepositClass`). `conversionOutput` takes the lane token.
- **One deposit class rule** (`depositClassFor`). A plain deposit, unpinned, and a stealth reshield
  take their class from it: under the AUTOVAULT bit vaulted to any recipient that is neither exempt
  nor the fee treasury (refused while the class takes no deposits), else a reshield the class of the
  bundle's payout (idle into a token whose vaulted class is not open), else vaulted while the class
  accepts unless the compliance engine last decided idle. So a stealth reshield of an idle payout of
  a bit-on token to a recipient that is not exempt is built vaulted, which the pool takes (pool#314),
  where the SDK built it idle and refused it.
- **Caps count units.** A payment of vaulted shares under a capped entry is charged its worth at its
  class's leaf in the class-index tree (`readClassIndex`, `classIndexWitnessAbi`, `cappedValue`),
  pinned when the transfer is prepared (`IPrepareOperation.classIndex`) and refreshed when the pool no
  longer accepts its root; a converted payment its worth at its lane's index; a released one its
  units (`Counterparty.cappedAmount`, `chargeOf`, `spendCounterparties` for approvers). Every transact
  carries a class-index root. A vaulted withdrawal states `statedWithdrawIndex(exactIndex(A, T))`,
  1 bps above the exact index the pool holds it to (`withdrawIndex`, `IPrepareOperation.statedIndex`),
  and charges its capped payees there. Removed: `policyCeilingOf`, `policyCapInUnits`,
  `rescaledShareCaps` and the ceilings' `index`, `holdsVaulted` and `underlying`.
- `proveWithinPeriod` and the relay also prove again on `StaleClassIndexRoot` (`isStaleProofError`).
  Account owners are warned when a recipient's exemption ends in the proof's window.

Migrate: relayer (fee UTXOs of an AUTOVAULT token arrive in shares; `StaleClassIndexRoot` passes
back like `StalePeriod`), the indexer (`CHAIN_EVENTS` adds `ReceiveExemptionSet` and
`AutovaultReleased`), safe-sdk (approvers sign the binding over `spendCounterparties`), testenv.

### BREAKING: the primitives of the next circuits release

What the next shtx-circuits release and pool check of signed meter ciphertexts, caps in underlying
units and the AUTOVAULT mandate, with known answers.

- `sealMeterNote` is deterministic: its nonce is `HKDF-SHA256(HKDF-SHA256(key,
'bermuda:meter-nonce-key:v1'), 'bermuda:meter-nonce:v1' ‖ plaintext, 24)`, so a note always seals
  to the same 232 bytes on every owner device. `meterCiphertextHash(ct)` is `keccak256(ct) mod p`, a
  meter slot's third public output, and `meterOutputsBinding(outputs)` chains each real step's
  `IMeterOutput` triple `(nullifier, note, ciphertextHash)` as the release's `meter_binding` does.
- `computeReceiveLeaf(rules, owner, next, senderRoot, memoPrefix, exemptUntil = 0n)`: a record carries
  its account's `exemptUntil` (u64) above the rules on the leaf's tag,
  `RECEIVE_LEAF_TAG + rules + 2^20 * exemptUntil`. A record without one hashes as before.
- `class-index.ts`: the class-index tree's `CLASS_INDEX_TREE_LEVELS` (8), `DOMAIN_CLASS_INDEX` (2) and
  `CLASS_INDEX_MAX_AGE` (24 periods), `classIndexKey(u)`, `classIndexValue(index, periodId)` and
  `classIndexLeaf(key, nextKey, value)`.
- `mulDivUp(a, num, den)` (`ceil(a * num / den)`; `a < 2^124`, value `< 2^163`), `priceTerms(vaulted,
index)` and `laneValue(amount, terms)`: how the circuits value a payment in another unit.
- BREAKING: the public-input readers take the release layout. A meter slot is a triple
  (`IMeterOutput` replaces `IMeterPair`; `METER_OUTPUT_WIDTH` is 3), a transact carries
  `classIndexRoot` before the three scalars, `period` is the plain period id (the reads drop
  `periodId` and `meterDigest`), and a lane's `conv_token` decodes into its underlying and
  `released`, set when a vaulted lane releases into the idle class (`u + 2^160`). Lengths: transact
  56/67/68/84 (2x4/4x8/2x16/16x4), withdraw 63/91, dox 66/94.
- `test/fixtures/shtx-kat.json`: the metered auth digest over triples (`meterTriples` replaces
  `meterPairs`), and known answers for meter ciphertexts and their hashes, receive leaves with an
  exemption, class-index leaves, `mulDivUp` and lane values, for the circuits' and the pool's tests.

### A rotated tree's UTXOs are found and kept

Leaf indices restart in every tree, but the scan resumed after the highest index it had decrypted
and the cache told UTXOs apart by index, so once the pool rotated its tree a UTXO in the new tree
was never scanned, a cached one at the same index dropped it, and forgetting or excluding one UTXO
dropped the other too. The scan now resumes after a (tree, index) mark, and the cache merges,
forgets and excludes by commitment. The cache's watermark carries `last_tree_number`; a cache
written before this throws on it.

### A cached or transported UTXO keeps a binary memo

The UTXO cache and `utxoToJSON` write the memo as 0x hex, not as UTF-8 text, and `utxoFromJSON` and
the cache read only 0x hex. A memo that is not UTF-8 (a lone 0xff) came back with U+FFFD in it, so the
UTXO no longer rebuilt its commitment and could not be spent until the cache was cleared. A cache
written before this throws on its memo.

### Issuer-served UTXOs are checked against the chain

`ingestIssuerUtxos({ keypair, token, items })` takes the token whose issuer served the items, and
accepts a UTXO only when the chain holds its commitment at its leaf index, it is the viewer's own,
and it is of that token. An issuer could otherwise show a balance the chain does not hold, shadow a
real UTXO at its index, or add to another token's balance.

### BREAKING: a sponsored burner batch signs its minimum gas

The sdk side of pool#305.

- BatchDelegate's `Execute` signs `minGas` after `deadline` (domain version still `"1"`), and
  `executeWithAuth` takes it before the signature: the delegate does not start the batch with less,
  so a relayer cannot starve a call that catches its own failure into its failure branch.
  `burnerAuthDigest` takes `minGas` after the deadline. The bundled BatchDelegate ABI is synced from
  the pool build.
- A sponsored stealth bundle signs `burnerMinGas`: the `eth_estimateGas` of its relayed call, signed
  with no minimum and carrying the EIP-7702 authorization of a fresh burner, plus
  `BURNER_MIN_GAS_MARGIN_PERCENT` (20%). Building one now estimates it, so the provider must serve
  `eth_estimateGas` with an `authorizationList`, and a bundle that reverts fails at build time with
  the estimate's error rather than at the relayer.

Migrate:

- **every chain:** a BatchDelegate deployed from pool#305 and its address in `chain.ts`
  (`batchDelegate`); a burner whose code still delegates to the old one cannot run a new bundle.
- **relayer:** the new `executeWithAuth` in its BatchDelegate ABI (`readCalls`).
- **testenv:** the `Execute` type and the `executeWithAuth` ABI of its burner tests, and this release.

### BREAKING: a pending dox withdrawal carries its redirect nonce

The bundled pool ABI follows pool#304 (e4c12a1): `pendingDoxWithdrawals(requestId)` returns a
`uint16 redirectNonce` after `isVaulted`, which `DoxWithdrawalRedirect(uint256 requestId,address
recipient,address newRecipient,uint256 nonce)` signs and each redirect bumps, so a redirect signature
is single-use. `pendingDoxWithdrawal` returns it (`IPendingDoxWithdrawal.redirectNonce`) and reads
the fields after it one position later; a caller decoding the getter by position shifts too. Needs
pool#304. The sdk sends no redirect, so it gains no signing helper.

### `statedIndex` is exported

`statedIndex(indexNow)`, the index a vaulted deposit's proof states, is exported next to
`sharesForAmount` and `valueOfShares`, so a payee's check can value shares at it. No behaviour change.

### A transfer short of balance and one short of compliant balance fail apart again

The balance check runs on every UTXO of the class (`Insufficient UTXO balance for transfer`) before
UTXOs that carry a blocklisted deposit id are dropped, so the compliant check (`Insufficient
compliant UTXO balance for transfer`) can fire again.

### `rulesBase` masks REFUSE_VAULTED as the pool does

`rulesBase(rules, memoPrefix)` hashes `rules & ~REFUSE_VAULTED`, as `InboundPolicies._rulesBase`
(pool eede0a4). A change queued by the sdk no longer reads as "not queued by this SDK" once the
refusal bit differs.

### The compliance key is read with `publicKey`

`complianceGatewayKey` calls `ComplianceGateway.publicKey()` (0x63ffab31), the renamed `getPublicKey()`
(0x2e334452) of pool 81337be, so every fee-rate path works against current pools.

### The circuit artifacts follow shtx-circuits#194

`src/circuits/31337/` vendors shtx-circuits#194 (c2e6599) artifacts/31337: line reductions with the
same statements. The `clawback_16` and `recover_16x16` verification keys change, so proofs need the
matching pool verifiers. No sdk code changes.

### BREAKING: the stated index sits half a bps above the fresh index

`statedIndex(indexNow)` is `indexNow + indexNow / 20_000`, not `indexNow - indexNow / 1_000_000`.
pool#288 takes a stated index only within `fresh <= idx <= fresh * (1 + 1 bps)`, so no booking
over-mints or lowers the class's index. A vaulted deposit or conversion gets at most 0.5 bps fewer
shares, which the class's holders keep, and its proof lands while the index rises less than about
0.5 bps. Needs pool main 1b94eea or later.

### The bundled ABIs follow pool main bdbf0f4

The sdk side of pool#286.

- `abandonedRecord`'s `shares` is a `uint256`; the pool declares `heldFees(token)`, `claimHeldFees(token)`, `FeesHeld` and `HeldFeesClaimed` (a protocol fee whose transfer fails is held until claimed), `RelayFeeGasTooLow`, `VaultRoundingLoss` (was `VaultEntryLoss`) and `depositsUnderRoot(blacklistRootNonce)`, and SafeAccounts' `setSigningKeyWithSignature`/`signingKeyDigest` take a `deadline`; no sdk code changes.

### BREAKING: the viewer root and the recovery salt are standard derivations

`KeyPair`'s viewer root, its X-Wing seed, is `HKDF-SHA256(I2OSP(sk, 32), salt ∅,
'bermuda:viewer-root:v1', 32)` (RFC 5869), not `blake2s(sk)`, and `computeRecoverySalt` is RFC 9380
`hashToFieldScalar(viewerRoot, 'bermuda:recovery-salt:v1')`, not `blake2s(viewerRoot ‖ DST) mod p`.
Every viewing key, recovery hash and shielded address changes, and with them every recoverable
owner commitment; no migration. The circuits take the salt as an input and compute neither.
Regenerate: testenv's `FEE_TREASURY_SHIELDED_ADDRESS` and the pool fixtures it proves.

### BREAKING: the proof-bound conversion index of shtx-circuits#190

`src/circuits/31337/` vendors shtx-circuits#190 (54df8b0) artifacts/31337. A conversion's proof
states the class index it priced at, and the pool takes it within `fresh * (1 - 10 bps) <= index <=
fresh`, so an index rise between proving and landing no longer reverts a conversion in flight.

- Each deposit id's converted shares are `floor(c_t * RAY / index)` at the class's fresh index
  (`conversionIndex`), the lane's shares their sum: no growth projection, no proportional split.
  `ILaneConversion` and the withdrawal's conversion (`IChangeConversion`) carry `index`;
  `convertLaneChange` takes `indexOf(token)` and `convertWithdrawChange` an `index`.
- Public inputs: transact lanes publish `(conv_token, conv_cs, conv_index)` (`conversionOutput`
  replaces `conversionPair`), withdrawals `conversion_index` after `conversion`. Lengths:
  transact 51/62/63/79 (2x4/4x8/2x16/16x4), withdraw 59/87, dox 62/90; `IConversion.index`.
- A vaulted deposit commits `floor(net * RAY / index)` shares at the class's fresh index, stated in
  its first lane's `conv_index`; `net` is the least that buys them exactly (`vaultedDepositNet(shares,
index)`). A fees-on-top recipient's shares round up to a count some `net` buys (`buyableShares`),
  which matters only below index 1. `/sign` receives the `index`.
- An OTC pack carries its leg's `conversionIndex`, and its share's `conversion` the `index`.
- Removed: `projectedGrowthPpm`, `conversionGrowthPpm`, `conversionShares` (now `sharesAt`),
  `sizeVaultedDeposit`, `assertVaultResidue`/`VaultResidueError`, `lineageHolds`,
  `DEFAULT_VAULT_GROWTH_BPS`, `DEFAULT_VAULT_DEPOSIT_WINDOW_SECONDS` and the config's
  `vaultGrowthBps`, `vaultDepositWindowSeconds` and `vaultConversionWindowSeconds`.
- Deposits and conversions state `statedIndex(indexNow)`, 1 ppm below the fresh index, for pool#284's window `fresh * (1 - 1 bps) <= index <= refIndex`.

### BREAKING: `WithdrawTerms` bind the class

`WithdrawTerms(bytes32 firstNullifier,address recipient,bytes32 payoutsHash,address token,bool
vaulted,uint256 amount,uint256 protocolFeeBps)`: a withdrawal voucher binds the withdrawal's class,
as `DepositTerms` do. `IWithdrawTerms`, `IWithdrawTermsRequest` and the engine's JSON carry `vaulted`,
and `assertVoucherBindsWithdrawal` checks it against the plan's class.

Migrate:

- **pool:** the verifiers of shtx-circuits#190, the window check on `conv_index`, and the new
  `WithdrawTerms` type.
- **compliance engine:** check a vaulted deposit's `shares == floor(net * RAY / index)` with the
  request's `index` in the window, instead of `shares * assets <= net * totalShares` at its own
  read; sign withdrawal terms with `vaulted`.
- **testenv:** shtx-circuits#190 and this release.

### BREAKING: the circuit input renames of shtx-circuits#188

`src/circuits/31337/` vendors shtx-circuits main 1232051 artifacts/31337; VKs and public inputs are
unchanged, so the deployed verifiers still verify. The witnesses spell the renamed keys
(`memo_hashes`/`memo_length`/`memo_packed`, `fee_rate_sig`/`fee_rate_granted`,
`deposit_attestation_sig`/`attested_deposit_id`, `extra_payees`, `exempt_until_period`,
`path_directions`, `new_key_preimages`, the cover's `broader`), and the SDK names follow:
`WITHDRAW_EXTRA_PAYEES` and `IWithdrawPayoutSplit.extraPayees`, the account settings'
`exemptUntilPeriod` (also `periodDeadlineWarnings`' argument), `ITransactProofPreimage`'s
`depositAttestationSignature`/`attestedDepositId`, and the preimages'
`exclusionPathDirections`/`inclusionPathDirections`. No behaviour change.

### BREAKING: the pool renames of pool#279

The bundled ABIs follow pool#279's renames; the SDK calls and signs under the new names, so it
needs a pool and registry deployed from it (an admin action hash covers the called selector).

- `inbound.execute`/`inbound.cancel` and `policy.execute`/`policy.cancel` are now
  `executeLoosening`/`cancelLoosening`, as the module functions they call.
- `IVaultConfig.pendingVaultAt`/`pendingFeeAt` are `pendingVaultProposedAt`/`pendingFeeProposedAt`,
  and `IVaultIndex`'s and `IVaultConfig`'s `abandonedOpen` is `openAbandonedCount`.
- `RECOVERY_IFACE`'s batch field `proof` is `recovery`.

### BREAKING: the Noir audit fixes of shtx-circuits#186 and #187

Proofs verify only against the verifiers of shtx-circuits main ef033318 (#186, then #187), whose
artifacts/31337 `src/circuits/31337/` now vendors; public inputs are unchanged.

- A deposit spends no notes: it carries only fresh value, one output per recipient under a fresh
  deposit id. A deposit with a real input is refused before anyone is asked, "a deposit spends no
  notes"; existing notes merge in a transfer. A deposit never converts, and every output of it looks
  up its recipient's receive record. The receive-side `DEPOSIT_WITH_INPUTS` refusal and
  `buildReceiveOpenings`' `hasInputs` are gone.
- **The `topup` deposit option is removed** (`IDepositOptions.topup`): a deposit no longer spends
  an existing UTXO to append its component. `allocateDepositComponents` takes no base UTXO.
- Each deposit id's shares in a conversion are its part rounded down or up,
  `|s_t * c_l - c_t * s_l| < c_l`, so an id whose part is worth a share keeps one. `splitLineage`
  already splits that way; `lineageHolds` checks the two-sided bound.
- A transfer names no depositor: refused rather than proved with a nonzero one.

Migrate:

- **pool:** the verifiers of shtx-circuits ef033318.
- **every chain's `artifacts` URL:** that chain's artifacts of ef033318.
- **callers of `deposit` with `{ topup }`:** drop it; merge notes in a transfer.
- **callers of `buildReceiveOpenings`:** drop `hasInputs`.
- **testenv:** shtx-circuits ef033318 and this release.

### BREAKING: the pool's signing formats

The sdk side of pool#277.

- BatchDelegate's `Execute` signs a `deadline` (domain version still `"1"`), and `burnerAuthDigest`
  takes it after the nonce. A sponsored stealth bundle signs until `IStealthParams.authDeadline`
  (default an hour past the latest block) at the burner's `nonce()`. The bundled BatchDelegate ABI
  is synced from the pool build.
- `DepositTerms` carry the deposit's class, `vaulted` (`IDepositTerms`, `/sign` JSON), checked
  before proving; `DepositAuthorization` binds the voucher's `depositTerms` struct hash
  (`depositTermsHash`, zero without one), passed as `depositAuthorizationOf`'s third argument.
- `WithdrawTerms` bind the whole payout split as `payoutsHash` after `recipient`:
  keccak256(abi.encode((address,uint256)[])) of the payees, payee 0 the recipient, padding left
  out, none on a doxxed withdrawal (`withdrawPayoutsHash`). A one-proof plan carries it
  (`IWithdrawPlan.payoutsHash`); `IWithdrawTermsRequest`, the `/sponsor/withdraw-terms` body and
  the engine's JSON carry it, and a voucher for another split is refused before proving.

### BREAKING: crypto audit fixes

Keys, seeds, Schnorr and signers.

- `KeyPair.deriveAccount` / `BermudaAccount.fromSigner` refuse a contract signer, and any signature
  that is not a 65-byte ECDSA signature recovering to the signer (a smart-contract wallet behind a
  wallet client too). The signature is normalized to low s and v 27/28 before it becomes the seed,
  so an account derived from a wallet that returned v 0/1 or a high s moves.
- Seeds are bytes or 0x-prefixed even-length hex: `KeyPair.fromSeed`, `deriveAccount({ seed })`
  and `BermudaAccount.fromSeed` throw on text and odd hex instead of reading it as UTF-8. Text
  is encoded by the caller: `KeyPair.fromSeed(utf82bytes(label))` gives the old text key.
- `hashToField` / `hashToFieldScalar` take bytes only; `domainSeparatorFromMessage` encodes its
  label as UTF-8. Every existing domain and hex-seeded key is unchanged.
- `KeyPair.deserialize` refuses a spending key outside [1, N) rather than reducing it.
- Schnorr signing nonces are hedged: HKDF-SHA256 over the key, message, domain and 32 fresh random
  bytes. Signatures verify as before; witness pins under seeded randomness moved.
- `schnorrVerifySignature` returns false on malformed input instead of throwing.
- The viem signing path picks the EIP-712 primary type as ethers does, not the first key.
- `util.inspect` / `console.log` of a `KeyPair` or `Utxo` print no secret.

### The pool's pashov round-4 surface in the bundled ABIs

The sdk side of the pool's pashov round-4 fixes (pool#276). ABI only; no sdk code changes.

- The bundled pool ABI declares the governor-only `evictIssuerPolicy(token, hint)`, its
  `IssuerPolicyEvicted(token)` event and the `IssuerLeafNotEvictable()` error.
- `IssuerPolicyUpdateRecorded` gains a trailing `bool isAutovault`, so its topic changes; the sdk
  does not decode it.
- SafeAccounts' `enrolledSingletonOf` is never 0 for an enrolled Safe: an uninstall keeps the pin and
  the first sync after the guard is re-armed re-pins the running singleton. `sync` now refuses a
  swapped singleton itself, with the `SingletonChanged(safe, pinned, found)` error SafeAccounts
  declares. Every resync, enroll and `clearSigningKey` deletes the keys of owners who left the Safe.
- Each deposit reserves one blacklist leaf: the pool ABI declares `depositsUnderRoot(blacklistRoot)`,
  and deposits revert `BlacklistTreeFull` once a root's `leafCapacity` is reserved, until the next
  root. The sdk reads neither.
- InboundPolicies declares `unbindAccount(owner, auth)`, its `ReceiveRecordUnbound(owner, accountId)`
  event and the `NotUnbindable(owner)` error: an account's admin frees the slot of a record whose
  rules are already 0. The sdk does not wrap account bindings.
- `recoverAbandoned` is governor-only (`NotGovernor` for anyone else), and a drain-mode redeem below
  its preview reverts `VaultMisbehaved`; the sdk calls neither `recoverAbandoned` nor `rebalance`.

### A rebinding keeps the record's rules; the AUTOVAULT turn-on clock

The sdk side of the pool's pashov round-3 fixes (pool#275).

- A rebinding writes the rules, memo prefix and sender root it proves, resets the update delay to 0
  and drops what the old writer queued or signed. `inbound.bind` on a bound record now defaults
  them to the record's current ones, so a writer change no longer wipes them.
- The bundled pool ABI declares `lastAutovaultOnAt(token)`: AUTOVAULT turn-ons keep their own
  cooldown clock, apart from `lastIssuerPolicyUpdateAt`.
- A deposit's protocol fee is checked as `floor(gross * bps / (10000 + bps))`; the fee the sdk sizes
  always equals it, so deposits are unchanged.

### BREAKING: a withdrawal voucher binds its fee base; a rebinding's writer applies at once

The sdk side of the pool's pashov round-2 fixes (pool c706a617).

- `WithdrawTerms.amount` is the withdrawal's fee base, `|extAmount| + relayFee` (a plan's
  `recipientTotal + relayFee`), where it was `|extAmount|`; the plan check, `IWithdrawTermsRequest`
  and `sponsorWithdrawTerms` follow it.
- `QUEUE_ITEM.InboundWriter` is gone and `InboundDelay` is 8 (was 9). `inbound.bind` on a bound
  record sets the new writer at once (the module drops what the old writer queued) and returns no
  `queued`. Every direct admin or writer call now consumes `adminNonce` / `writerNonce` too.
- The bundled ABIs follow the pool: `autovaultOn`, `configureVaultClass` and `syncAutovault` take a
  trailing `bytes32 hint`; `roots`, `currentRootIndex` and `ROOT_HISTORY_SIZE` are gone; PoolConfig's
  `lastPause` is replaced by `pausedSeconds`, and a recovery session carries `pausedSecondsAtSubmit`.

### viem 2.57.11; built with TypeScript 7

- `viem` is `2.57.11` (was `2.55.19`); `ethers` stays `6.17.0`. A consumer that hands the sdk viem
  clients or accounts, or ethers signers, pins these versions so the types line up.
- The build runs TypeScript 7.0.2. The emitted JavaScript is unchanged; the declarations differ only
  in quote style and union order.

### BREAKING: a withdrawal's protocol fee covers its relay fee; conversions size at the fresh index

The sdk side of the pool's fixes of findings 6 and 14 of the pashov scan of pool c9167382.

- A withdrawal (plain, dox or vaulted, in its class's units) pays the protocol fee on its recipient
  amount plus its relay fee, `floor((|extAmount| + relayFee) * bps / 10000)`, where the base left
  the relay fee out. `resolveWithdrawStepAccounting`, the withdraw plan's estimates and checks, and
  so stealth unshields and split payouts, follow it. Deposits are unchanged.
- A forced conversion of idle change (a transfer's, a withdrawal's or an OTC leg's) sizes its shares
  at the class's `vaultIndex` `indexNow`, which the pool now accrues to first, where it used
  `lastIndex`; the `conversionGrowthPpm` margin stays. While the class is unvalued, not accepting or
  unseeded, the new `conversionIndex` refuses the spend before proving, as the pool would: it waits
  until AUTOVAULT is off.
- The bundled ABIs follow the pool: `pendingDoxWithdrawal` returns the deferred `relayer` and
  `relayFee`; `poolConfig.terms()` drops `recoveryBond` and renames `recoveryTimeLock` to
  `recoveryDelay` and `pendingRecoveryTimeLock` to `pendingRecoveryDelay` (`{ delay, effectiveAt }`);
  `RECOVERY_IFACE` drops `expireRecovery`.

Migrate:

- **pool:** the fixes of findings 6 and 14. Against an earlier pool, a withdrawal that pays a relay
  fee at a nonzero rate reverts `InvalidProtocolFee` whenever the two bases' fees differ.
- **anything that prices a withdrawal's protocol fee itself** (a relayer's quote): the new base.

### BREAKING: the witness structs of shtx-circuits#185

Proofs verify only against the verifiers of shtx-circuits#185 (head 6edb8d9f), whose artifacts/31337
`src/circuits/31337/` now vendors. The private-input ABI is nested; public inputs are unchanged.
Every circuit but policyUpdate has new bytecode, so ten verifiers change.

- The transact, withdraw, withdraw_dox and OTC 4x8 witnesses pass their notes and openings as the
  circuits' structs:
  - `ins` (`InputNotes`): `amounts`, `blindings`, `nullifier_secrets`, `utxos`, `path_elements`,
    `path_depths`, `path_directions`, `sub_deposit_ids`, `sub_deposit_amounts`, formerly
    `in_<field>`;
  - `outs` (`OutputNotes`): `amounts`, `owner_ids`, `blindings`, `nullifier_secrets`,
    `utxo_length`, `utxo_packed`, `sub_deposit_ids`, `sub_deposit_amounts`, formerly
    `out_<field>`;
  - `spend_auth` (`SpendAuth`, transact): `pubkeys_x`, `pubkeys_y`, `sigs`, `recovery_hashes`,
    formerly `spend_pubkeys_x`, `spend_pubkeys_y`, `spend_auth_sigs`, `spend_recovery_hashes`;
  - `spender` (`SpendKey`, withdraw and withdraw_dox): `pubkey_x`, `pubkey_y`, `sig`,
    `recovery_hash`, formerly `in_pubkey_x`, `in_pubkey_y`, `in_spend_auth_sig`, `recovery_hash`;
  - `exclusion` and `inclusion` (`IndexedPaths`): `leaf_next_keys`, `path_indices`,
    `path_elements`, `path_depths`, formerly `exclusion_<field>` and `inclusion_<field>`.

  `in_tokens`, `in_nullifiers`, `in_spender_indices`, `out_tokens`, `out_commitments`,
  `out_converted`, `exclusion_root`, `exclusion_leaf_keys` and `inclusion_root` stay flat. The
  values are unchanged: the pinned witnesses, flattened back, hash as before.

- `ISharedCircuitInputArgs` and `IWithdrawCircuitInputArgs` nest them, typed by the new
  `IInputNotes`, `IOutputNotes`, `ISpendAuth`, `ISpendKey` and `IIndexedPaths`.

Migrate:

- **pool:** the ten changed verifiers of shtx-circuits#185 (all but `policyUpdateVerifier`).
- **every chain's `artifacts` URL:** the #185 artifacts of that chain.
- **safe-sdk** (the recover witness): `ins` and `outs`.
- **issuer-sdk** (the clawback witness): `owner_ids` and `notes` (`InputNotes`, the memo hash in
  `notes.utxos`), formerly `amount`, `owner_id`, `blinding`, `memo`, `sub_deposit_ids`,
  `sub_deposit_amounts`, `nullifier_secret`, `path_elements`, `path_depths`, `path_directions`.
- **testenv:** shtx-circuits#185 and this release; regenerate the pool and recovery fixtures.

### BREAKING: no `AnySigner#readContract` or `safeContract`; Schnorr nonces by `mapHashToField`

- `AnySigner#readContract` is gone: `permit` reads the token itself, through the signer's ethers
  provider or else its viem client, as the method did.
- `SAFE_OWNER_ABI`, `SAFE_MSG_TYPES`, `encodeSafeSignatures` and `SafeSignatureEntry` move from
  `anysigner.ts` to `safe-signatures.ts`; `@bermuda/sdk/internal` exports them unchanged.
  `safeContract` is removed: reading a Safe's owners is safe-sdk's.
- `sampleSchnorrNonce`, and so every Schnorr nonce and every fresh issuer key, is noble's
  `mapHashToField(randomBytes(48), N)`, FIPS 186-5 A.4.1's `k mod (N - 1) + 1`, where it reduced
  mod N and redrew a zero. Signatures verify as before; the witness pins move.
- Declarations leave the critical modules for `types.ts`: the UTXO envelope's and HPKE's types
  (`IHpkeContext`, `UtxoRecipient`, `IUtxoSealed`, `UtxoAccept`, `IUtxoOpened`, `IUtxoLeaf`) and
  Grumpkin's (`GrumpkinPointBytes`, `SignatureBytes`, `SignatureFields`), exported as before and
  with the other types.

Migrate:

- **safe-sdk:** its own `safeContract(safe, provider)` over `SAFE_OWNER_ABI` (still exported by
  `@bermuda/sdk/internal`), which `src/safe.ts` and `src/safe-account.ts` use and the package
  exports; `check:exports` no longer lists it as shared with the SDK.
- **issuer-sdk:** `safeContract` from `@bermuda/safe-sdk` in `src/clawback.ts` and
  `src/issuer-safe-ceremony.ts`; `check:exports` compares it with safe-sdk's.
- Nothing calls `AnySigner#readContract`.

### BREAKING: the UTXO envelope has no version qualifier

The UTXO envelope is the only one, so its names and labels say so.

- Labels: `bermuda:utxo:v1`, `bermuda:utxo:out:v1` and `bermuda:utxo:ovk:v1`, as every other
  `bermuda:` label. Every UTXO body and key moves, and with them every witness pin
  (`test/fixtures/utxo-kat.json`, regenerated by `scripts/gen-utxo-kat.mjs` and re-derived by
  `scripts/check-utxo-kat.py`).
- `@bermuda/sdk/internal`: `openUtxoProof`, `openUtxoDetached`, `sealUtxoOutputs`, `utxoInfoOf`,
  `utxoSlotCount`, `encryptedOutputsOf` and `UTXO_MAX_DETACHED_LENGTH`, formerly `openUtxoV2Proof`,
  `openUtxoV2Detached`, `sealUtxoOutputsV2`, `utxoV2InfoOf`, `utxoV2SlotCount`, `encryptedOutputsV2`
  and `UTXO_V2_MAX_DETACHED_LENGTH`. Every module-level `…V2` / `UTXO_V2_…` name drops `V2` the same
  way; the generic openers are `openUtxoProofWith` and `openUtxoDetachedWith`.

Migrate:

- **relayer, safe-sdk, testenv, eezy:** the new names, and this release on every side: a body sealed
  under the old labels does not open.

### BREAKING: Noir 1.0.0-rc.6 and bb 6.0.0

Proofs verify only against the verifiers of shtx-circuits b70e1384 (shtx-circuits#184), whose
artifacts/31337 `src/circuits/31337/` now vendors. bb 6 draws full-width Fiat-Shamir challenges, so
a bb 5 proof fails a bb 6 verifier and a bb 6 proof fails a bb 5 one.

- `@aztec-foundation/bb.js 6.0.0` replaces `@aztec/bb.js 5.2.1` (the package moved scope), and
  `@noir-lang/noir_js` is `1.0.0-rc.6`. The provers' API and the proof size are unchanged.
- The artifacts gain `artifact_version` and `abi.abi_version` (both 1). Witnesses are unchanged: the
  same input names, order and values.
- bb.js 6 no longer logs every proof, so proving no longer wraps `console.log`.

Migrate:

- **pool:** the bb 6 verifiers of shtx-circuits b70e1384.
- **every chain's `artifacts` URL:** the b70e1384 artifacts of that chain.
- **consumers of bb.js types** (`ProofData`): import them from `@aztec-foundation/bb.js`.

### BREAKING: one recovery binding; issuer UTXOs are read by viewing key only

Proofs verify only against the recover verifier of shtx-circuits d2b40357 (shtx-circuits#183), whose
artifacts/31337 `src/circuits/31337/` now vendors.

- `computeRecoveryBinding(recoverySafe, salt, minDelay = 0n)` is
  `poseidon2(recoverySafe, salt, minDelay)` at every delay, 0 included (the pool's time lock
  alone), as the circuit's `compute_recovery_binding`. Every recoverable key's owner commitment, and
  so its address, moves; an unbound key (`recoveryHash` 0) keeps its own.
- `initIssuerUtxos` returns `{ fetchIssuerUtxosByViewer }` only, and `findUtxos` reads every issuer
  that way: the spend key never signs for a read. `fetchIssuerUtxos`, `issuerUtxosChallenge` and
  `ISSUER_UTXOS_DOMAIN_FIELD` (`bermuda:issuer:notes:v1`) are gone, and with them `/utxos`
  `kind: 'spend'`.

Migrate:

- **issuer-sdk:** drop the `/utxos` `kind: 'spend'` login; `kind: 'viewer'` is the only read.
- **safe-sdk:** account recovery bindings and their test vectors move with `computeRecoveryHash`.
- **pool:** the new recover verifier.

### BREAKING: the shtx_hash binds the pool; receipts and owner approvals bind one settlement

Proofs verify only against the verifiers of shtx-circuits a1135bf0 (shtx-circuits#182), whose
artifacts/31337 `src/circuits/31337/` now vendors.

- `shtxHashOf(transaction, chainId, pool)`: the shtx_hash hashes the pool after the chain id
  (`proofPoolAddress(config)`, the proof's `pool_address`); so does a deposit's `compliance_hash`.
- `computeAuthDigest(accountId, authVersion, ownerId, shtxHash, meters = 0n)` and
  `authDigests(chainId, state, shtxHash, meters = 0n)`: the chain and the pool come through the
  shtx_hash; `meters` is the account's `meterBinding` (its real meter steps), which `handOverMeters`
  returns as `meters.binding` and every owner computes from its own meter scan. A plan whose
  `meters.binding` differs from the steps the proof would make is refused before proving.
- Issuer receipts sign `issuerReceiptMessage({ kind, shtxHash, senderOwnerId, laneToken, outputsHash,
issuerHeldUtxos })` under `bermuda:receipt:v2` and `bermuda:recovery-receipt:v2`: a receipt settles
  at most one proof. `/sign` v3 carries `transaction`, the shtx_hash preimage, in place of `validity`
  and `outputCount`; `requestIssuerReceipts` and `requestLaneReceipt` take it, and
  `finalizeShtxHash` (now async) requests the receipts once the shtx_hash is final.
- `buildAssembly(shares, root, chainId, pool, validity, utxoInfo)`.
- An account with a list refuses an open-market relay fee (relayer 0): `chooseEntry` throws, as the
  circuit's `police` refuses it.
- A transfer selects no UTXO that carries a blocklisted deposit id (`carriesListed`): transact
  refuses it, and it leaves through a withdrawal.

Migrate:

- **issuer-sdk:** serve `/sign` v3 as `issuer-policy.ts`'s wire comment says: compute the shtx_hash
  from `transaction` with its own chain and pool, find each output at its position in
  `transaction.commitments`, check its window on `transaction.validity`, sign the v2 message.
- **compliance-engine:** the pool after the chain id in `compliance_hash`, and its own pool in
  `shtxHashOf`.
- **safe-sdk:** `authDigests` without the pool and with each owner's own `meterBinding`; a recovery's
  receipts over its batch's `transaction`.
- **pool:** the new verifiers.

### BREAKING: the circuits accept one encoding of a Schnorr signature

Proofs verify only against the verifiers of shtx-circuits 9b618dbc (shtx-circuits#181), whose
artifacts/31337 `src/circuits/31337/` now vendors; the 96e1f065 pin below no longer holds.

- Every Schnorr-verifying circuit checks `0 < z < N` on 128-bit limbs and takes the canonical
  decomposition of the challenge `c` as its scalar, as `schnorrVerifySignature` already did:
  `(R, z + N)` no longer passes beside `(R, z)`. SDK signatures are unchanged and still verify.
- transact, withdraw, withdraw-dox, recover and policyUpdate have new bytecode and verifiers; no ABI
  changes, and clawback16 changes only its debug info and program `hash`.

Migrate:

- **pool:** the shtx-circuits 9b618dbc verifiers.

### BREAKING: the deposit attestation has its own Schnorr domain

Proofs verify only against the transact verifiers of shtx-circuits 96e1f065 (shtx-circuits#179), whose
artifacts/31337 `src/circuits/31337/` now vendors.

- The compliance key signs a deposit's `compliance_hash` under `DEPOSIT_ATTESTATION_DOMAIN_FIELD`,
  `hash_to_field("bermuda:deposit-attestation:schnorr:v1")` (the circuits'
  `DEPOSIT_ATTESTATION_SCHNORR_DOMAIN`), no longer under the spend-auth domain: a spend
  authorization or a granted fee rate does not pass as an attestation.
- New exports: `DEPOSIT_ATTESTATION_DOMAIN_FIELD`, `signDepositAttestation(privkey, complianceHash)`
  and `verifyDepositAttestation(pubkey, complianceHash, signature)`.

Migrate:

- **compliance-engine:** sign `/sign`'s attestation with `signDepositAttestation(privkey, hash)`
  instead of `keypair.sign(hash)`.
- **pool:** the shtx-circuits 96e1f065 transact verifiers.

### BREAKING: dox withdrawals, and their delayed release

The pool calls the public withdrawal a dox withdrawal everywhere, and its delayed claim a release
(pool `releaseDoxWithdrawal`; ClaimLib is folded into TransactLib).

- EIP-712: the recipient signs `DoxWithdrawal(bytes32 shtxHash)`. A signature of the old
  `PublicWithdrawal` no longer verifies.
- Renamed exports: `DOX_WITHDRAWAL_TYPES`, `doxWithdrawalTypedData`, `doxWithdrawalDigest`,
  `DoxWithdrawalSigner`, `IDoxWithdrawalTypedData`, `IDoxWithdrawProofPreimage`,
  `IPendingDoxWithdrawal` and `IDoxWithdrawalRequest` (`claimed` is `released`).
- The SDK: `doxWithdraw`, `releaseDoxWithdrawal` (was `claim`), `doxWithdrawalDelay`,
  `pendingDoxWithdrawal` and `findDoxWithdrawalRequests`; the core's `prepareDoxWithdraw` and
  `getDoxWithdrawProof`; `txKind: 'doxWithdraw'`.
- PoolConfig: the term `doxWithdrawalDelay` (`doxWithdrawalDelaySeconds`), the pause level
  `doxWithdrawalsOnly` and the pausable operations `doxWithdrawal` and `doxWithdrawalRelease`.
- Pool ABI: `releaseDoxWithdrawal`, `pendingDoxWithdrawals` (`releasableAt`), `doxWithdrawalNonce`,
  the events `DoxWithdrawalProven`, `DoxWithdrawalRequested` and `DoxWithdrawalReleased`, the errors
  `UnknownDoxWithdrawal` and `DoxWithdrawalNotReady`; PoolConfig `setDoxWithdrawalDelay` and
  `DoxWithdrawalDelayUpdated`.
- Presets: one pool library fewer moves every later CREATE of the fixed deploy orders. `eez-rollup-x`:
  pool (nonce 32), multicall (33) and batchDelegate (34). `testenv`: pool (27), multiSendCallOnly
  (29), batchDelegate (35), multiSend (36) and signMsgHashLib (37).

Migrate:

- **pool:** the renames above and the `DoxWithdrawal` typehash.
- **Callers:** follow the renamed exports, SDK methods, terms and pause names.

### BREAKING: no compliance attestation on withdrawals and recoveries

Proofs verify only against verifiers of shtx-circuits 8db18825 (shtx-circuits#178); the 9b0384fb pin
below no longer holds for withdraw, withdraw-dox and recover.

- withdraw, withdraw_dox and recover drop `compliance_pubkey_x`, `compliance_pubkey_y`,
  `attestation_sig` and `attestation_required`. Withdrawal witnesses no longer carry them, and the
  public inputs shrink by two: withdraw 58/86, withdraw-dox 61/89, recover 75. The heads in
  `public-inputs.ts` follow (`RECOVERY_PUBLIC_INPUT_INDEX`, `RECOVERY_PUBLIC_INPUT_LENGTH`), and
  `IRecoveryPublicInputs` loses `compliancePubkey`. Transact keeps its compliance key, the deposit
  attestation and the granted fee rate.
- Removed exports: `signAttestation`, `verifyAttestation` (index, internal), `attestationInputs`
  (internal), `ATTESTATION_DOMAIN_FIELD` (grumpkin-schnorr), and the unread `IConfig.attestation`.
- The verifying keys of the four withdraw and withdraw-dox shapes and recover16x16 change; the
  transact shapes, clawback16 and policyUpdate keep theirs. The withdrawal witness pins move.

Migrate:

- **pool:** the shtx-circuits 8db18825 verifiers and the shorter withdrawal and recovery layouts.
- **safe-sdk:** build recovery witnesses without `attestationInputs`.
- **compliance-engine:** stop importing `signAttestation` / `verifyAttestation` (tests).

### BREAKING: `bermuda:` protocol strings, EIP-712 public withdrawals and burner batches

Proofs verify only against verifiers of shtx-circuits 9b0384fb (shtx-circuits#177); the 40d18e1d pin
below no longer holds.

- No protocol string says `bermudabay` any more. The changes:
  - Schnorr domains and tags: the DST is `bermuda:schnorr-domain:v1` and every domain and tag is
    `bermuda:…`, matching the circuits.
  - Spend key and recovery salt: the DSTs are `bermuda:sk-spend:v1` and `bermuda:recovery-salt:v1`.
  - KeyDerivation (EIP-712): the domain name is `Bermuda` and `purpose` is `bermuda:account:v1`.
  - Burner key: the label is `bermuda:burner-account:<id>:v1`.
  - Envelopes:
    - transport: `bermuda:xwing-xchacha20poly1305:v1`;
    - UTXO: `bermuda:utxo:v1`, `bermuda:utxo:out:v1`, `bermuda:utxo:ovk:v1`;
    - the issuer transport, meter, policy-list and policy-handle and sealed-board labels;
    - OTC pad slots: `bermuda:otc:pad-slot:<i>:v1`.
  - Receipt domains: `bermuda:receipt:v1` and `bermuda:recovery-receipt:v1`.
- The same seed or signer now derives another account: another spend key, viewer, owner id and
  address. Anything sealed under an old label opens only with the old SDK.
- Public withdrawals: the recipient signs the EIP-712 `PublicWithdrawal(bytes32 shtxHash)` in the
  pool's domain, `{ name: 'BermudaPool', version: '1', chainId, verifyingContract: pool }`. It no
  longer signs the raw `shtx_hash`.
  - A `recipientSigner` callback receives `(digest, typedData)`: the EIP-712 digest the pool
    verifies and its typed data.
  - New exports: `PUBLIC_WITHDRAWAL_TYPES`, `publicWithdrawalTypedData` and
    `publicWithdrawalDigest`.
- Burner batches: a sponsored burner signs BatchDelegate's EIP-712
  `Execute(uint256 nonce,bytes32 mode,bytes executionData)` (`burnerAuthDigest`) in the domain
  `{ name: 'BermudaBatchDelegate', version: '1', chainId, verifyingContract: burner }`.

Migrate:

- **pool:** the new tag constants and verifiers. EIP-712 `PublicWithdrawal`, `RecoveryManifest`
  and `RecoveryCancel` in the pool domain, and BatchDelegate's `Execute`.
- **Wallet prompts that match the key-derivation request** (psd, eezy): read the purpose
  `bermuda:account:v1` and the domain name `Bermuda`.
- **`recipientSigner` callbacks:** a callback that signs the 32 bytes it is handed keeps working.
  A wallet signs `typedData` with `signTypedData` instead.

### BREAKING: the circuits of shtx-circuits 40d18e1d

Proofs verify only against verifiers of shtx-circuits 40d18e1d (shtx-circuits#173, #174); the 3c6b23c8
pin below no longer holds.

- The verifying keys of the four transact shapes and the four withdraw and withdraw-dox shapes
  change; recover16x16, clawback16 and policyUpdate keep theirs. Witnesses are unchanged: the same
  input names, order and values, and every witness pin holds.
- The structs in `policyUpdate`'s ABI keep their fields; their paths are
  `policy_update::{Binding, Cover, EntryPreimage, SenderEdit}`.
- The artifacts' `file_map` paths are repo-relative.

### BREAKING: one KeyPair serializer, a narrower critical set and an unbiased Schnorr nonce

- `keyPair.serialize()` is the shielded address; `serialize('viewing-key')` is an `IViewingKey`
  (`viewingKey`, `spendKeyHash`, `recoveryHash`, `recoveryMinDelay`, as hex) and
  `serialize('spending-key')` an `ISpendingKey` (`privkey`, with `recoveryHash` and
  `recoveryMinDelay` when bound: what a signable keypair's `toJSON` wrote). `KeyPair.deserialize`
  reads these three forms back and nothing else. A viewing key carries no version and no address,
  which derives from it. Gone, without aliases: `KeyPair.exportBackup`, `KeyPair.fromBackup`,
  `KeyPair.fromJSON`, `BermudaAccount#exportBackup`, `BermudaAccount.fromBackup` and
  `IViewingKeyBackup`. Version-4 backups and `{ address }` JSON are not read.
- `KeyPair#toJSON` returns the address string for every keypair, so `JSON.stringify` never writes a
  key (it wrote `{ privkey, ... }` for a signable keypair). `IShieldedOwner.toJSON` returns
  `unknown`.
- `KeyPair.fromString` is gone: `KeyPair.fromAddress`.
- `@bermuda/sdk` no longer exports `shtxHashFromPublicInputs`, `signPublicWithdrawalDigest` or
  `buildPublicWithdrawalSignature`: a public withdrawal signs through its params' `recipientSigner`.
- `/internal` no longer exports `strxor`, `expandMessageXMD`, `multiplyPoint`, `addPoints` or
  `registerShieldedOwnerReviver`.
- `Utxo#toJSON` and `Utxo.fromJSON` are gone; the OTC transport writes the same text through
  `utxoToJSON` / `utxoFromJSON` (`utxo-cache.js`), and `JSON.stringify(utxo)` throws on its bigints.
- `computeRecoverySalt`, `computeRecoveryBinding`, `computeRecoveryHash`, `MAX_RECOVERY_MIN_DELAY`,
  `KEY_DERIVATION_TYPES` and `keyDerivationDomain` live in `keypair.js` (`/internal` exports them as
  before; a deep import of `build/src/primitives.js` breaks). New: `KeyPair.deriveAccount` and
  `KeyPair#bindRecovery`.
- A Schnorr nonce reduces 48 random bytes mod the Grumpkin order: 32 bytes left a modulo bias at
  statistical distance 0.039. Signatures made under a seeded RNG change (the SDK's seven witness
  pins); every signature still verifies under the same key. A Grumpkin private key that is not 32
  bytes or is zero is refused as `Scalar must be ...` (was `Private key must be ...`).

Migrate:

- compliance-engine `src/config.ts:259` and eezy `stack/svc/tools/ce-pubkey.ts:9`:
  `KeyPair.fromJSON({ privkey })` is `KeyPair.deserialize({ privkey })`.
- testenv: `tests/helpers/fee-suite.ts:730` (`fromJSON` to `deserialize`);
  `tests/issuer-utxo-receipt.test.ts:607,636` and `tests/account-recovery.test.ts:450`
  (`KeyPair.fromBackup(x.exportBackup())` is `KeyPair.deserialize(x.serialize('viewing-key'))`);
  `scripts/fixtures/src/recovery-fixtures.mjs:141-142` takes `computeRecoverySalt` and
  `computeRecoveryBinding` from `keypair.js`; regenerate the pool fixtures (`gen:pool-fixtures`),
  whose seeded Schnorr signatures change.
- safe-sdk: drop the unused `registerShieldedOwnerReviver` import (`src/index.ts:2`); the
  `KeyPair.fromBackup` hint in `src/recover.ts:633` names `KeyPair.deserialize`.
- issuer-sdk, private-safe-demo, wdk-wallet-evm-bermuda, zerodev-demo, ubs-examples, x402-sdk and
  the relayer call none of these.

### BREAKING: shtx names, circuit tags and strict hex2bytes

Proofs verify only against verifiers of shtx-circuits 3c6b23c8 (pool 67aabdd9).

- `stx` is `shtx` in every name and field: `stxHash` is `shtxHash` (the sponsor fee-rate request
  body and the Safe proposal fields included), `STX_*` and `MAX_STX_*` are `SHTX_*` and
  `MAX_SHTX_*`, and `IStxPreimage`, `stxHashOf`, `stxHashFromPublicInputs`, `transferStxPreimage`
  and `otcStxPreimage` are `IShtxPreimage`, `shtxHashOf`, `shtxHashFromPublicInputs`,
  `transferShtxPreimage` and `otcShtxPreimage`.
- Every circuit tag is `hash_to_field("bermudabay:shtx:<name>:v<n>")` (shtx-circuits#171): the
  spend-auth Schnorr domain, `OWNER_ID_TAG` and the 15 registry, policy and meter tags, the seven
  keccak `safe-aux` ones included. The SDK-only addr-binding domain hashes
  `bermudabay:shtx:addr-binding:schnorr:v1`, and `PAD_LEAF` is the pool's
  `hash_to_field("bermudabay:shtx:pad:v1")`. Owner ids, shielded addresses, spend-auth and
  address-binding signatures, registry leaves and meters all change.
- `hex2bytes` throws a `TypeError` on anything but an optional `0x` and whole hex bytes; it read
  `'0g'` as 0x00 and `'-1'` as 0xff. `concatBytes` and `randomBytes` are `@noble/hashes`' and
  `bytes2bigint` is `@noble/curves`' `bytesToNumberBE`: they refuse a non-`Uint8Array`, and
  `randomBytes()` draws 32 bytes.
- The pool ABI: `NotSafeAccounts`, `ShtxHashNotFound`, `DuplicateShtxHash`, the `shtxHash`
  event fields.

Imports to change first:

- compliance-engine: `stxHashOf` and `IStxPreimage` (`src/grant-spends.ts:29-30`),
  `STX_SPEND_AUTH_DOMAIN_FIELD` (three test files); it also reads `body.stxHash` on
  `/sponsor/fee-rates` (`src/sponsors.ts:321`) and copies the old `PAD_LEAF` (`src/linking.ts:69`).
- safe-sdk: `STX_DEPOSIT_COMPONENTS` (`recover.ts`, `safe.ts`, `vault-class.ts`, 11 test files),
  `STX_DEPOSIT_ID_SLOTS` (`safe-otc.ts`), `STX_SPEND_AUTH_DOMAIN_FIELD` (`safe.ts`,
  `shielded-account.ts`, two test files) and `stxHashOf` (`recover.ts`), and every `stxHash` it
  reads off a prepared transaction, recovery batch, fee-rate grant or Safe proposal.
- issuer-sdk: `MAX_STX_OUTPUT_UTXOS` (`utxo-service.ts`, `issuer-receipt.ts`, two test files) and
  `STX_INDEXED_LEVELS` (one test file). relayer: `MAX_STX_OUTPUT_UTXOS` (`tests/forward.test.ts`).
- private-safe-demo, zerodev-demo, ubs-examples and x402-sdk import none of these.

### BREAKING: the pool's final names, key accounts removed

- `IConfig.burnerAccount` is `batchDelegate`; the bundled ABI `authmulticall` is `batch-delegate`.
- `burnerAuthDigest` leads with `keccak256("bermuda.batch-delegate.execute.v1")`. The presets'
  untagged AuthMultiCall deploys reject it: sponsored stealth needs the next BatchDelegate deploy.
- SafeAccounts is the registry's one account module. `resolveModules` returns
  `{ safeAccounts, inboundPolicies }` from the core's two-address `modules()`, the bundled
  `key-accounts.abi.json` is gone and the `account-policies` sync family reads SafeAccounts alone.
- `QUEUE_ITEM` follows `IRegistryModule.Item` without `Controller`: `Delay` 4, `CoSigner` 5,
  `SenderRoot` 6, `InboundRules` 7, `InboundWriter` 8, `InboundDelay` 9.
- `ACCOUNT_MODULE_DOMAIN_NAMES` is `SAFE_ACCOUNTS_DOMAIN_NAME` (`BermudaSafeAccounts`).
  `initPolicy` and `initInbound` take a `safeAccounts` dep returning the module in place of
  `accountModule`; `IAccountModuleRef` is gone.
- The `testenv` and `eez-rollup-x` presets follow their deploys without the KeyAccounts create:
  every address created after it is one nonce lower.

### BREAKING: development API and persistence cleanup

- Account seed derivation appends the 32-byte account id for every id, including zero. Accounts
  derived with id zero now have different keys and addresses. An omitted burner id is zero, so
  `burnerAddress({ spender })` and `burnerAddress({ spender, id: 0 })` name the same wallet.
- Viewing-key backups accept version 4 with an explicit `minDelay`. KeyPair JSON preserves
  `recoveryMinDelay` when set. UTXO JSON requires the current `vaulted`, `memo` and deposit-component
  fields; issuer-policy JSON requires its current fields. The old `note` and `withholdRequired`
  names and the old commitment-events cache import are removed.
- The `PasskeySigner` type, the `isPasskeySigner` brand and guard and `/internal`'s `initProve`
  alias are gone: use `ContractSigner`, `isContractSigner` and `initProver`. A contract owner is
  branded `isContractSigner` alone and `AnySigner` no longer sets `isPasskeySigner`, so safe-sdk,
  issuer-sdk and testenv must read `isContractSigner` before they take this SDK.
- `hex` uses the current ethers v6 inputs; the ethers v5 `BigNumber.toHexString()` adapter is
  removed. Unused internal parameters and repeated signer-wrapper checks are removed.
- `signedDepositValidity` requires the `/sign` response's `notBefore`, `notAfter` and `validity`;
  the engine-predating `expiryBlockNumber` fallback and field are removed.

### BREAKING: circuits after stx-circuit's audit fixes

The bundled circuits are stx-circuit's after its 2026-10-20 audit fixes, and their proofs verify
only against a pool deployed with the matching verifiers. Public inputs and every signed message
are unchanged.

- On a transfer, the treasury receives at most the fee at the pool's rate,
  `ceil(third * fee_bps / 10000)`, whatever a grant lowers the floor to, so nothing at 0 bps or
  without a third-party outflow, and a deposit pays it nothing. Every UTXO to the treasury counts,
  a payment to its address included. `assertTransferFeePaid` takes the pool's rate as `poolBps`
  and, with `assertDepositCap`, refuses such outputs before proving; `laneTreasuryReceived` (on
  `/internal`) is what the circuit caps.
- The other fixes change nothing the SDK builds: a recovery's minimum delay below 2^32, a clawback
  token id below 2^161, a memo prefix rule that reads the prefix's own bytes, and an account slot
  that spends nothing.

Regenerate: the pool's real-proof fixtures (testenv's `gen:pool-fixtures` and
`gen:recovery-fixtures`).

### Changed

- The critical modules are narrower (2,620 to 2,196 nSLOC): `primitives.ts`' non-cryptographic
  helpers live in `helpers.ts`, the UTXO cache codec in `utxo-cache.ts` and the plain signer and
  request types in `types.ts`, each re-exported where it was, so no import path changes.
- License: BUSL-1.1 (LICENSE) replaces FSL-1.1-ALv2 (LICENSE.md).

## `v0.3.4`

2026-10-21

### Changed

- A `stealth` bundle whose unshields pay vaulted value reshields idle into a token whose vaulted
  class is not open (none, or closed), such as a swap from vaulted USDC into WETH, instead of
  refusing it. Such a token takes only idle value, and the pool takes an idle deposit of it whatever
  class it paid the depositor in. A reshield token whose class is open but takes no deposits, or
  cannot be valued, is still refused. Needs a pool with that rule (v0.3.4); an older pool reverts
  the bundle `PayoutClassMismatch`.

## `v0.3.3`

2026-10-20

### BREAKING: UTXO envelope v1 removed

Every pool seals and scans UTXO envelope v2 alone (under Added); a v0.3.2 pool's notes open with the
v0.3.2 SDK. Gone, with the empty padding mode and the per-chain switch: `Utxo.encrypt`,
`Utxo.decrypt`, `Utxo#safe` and `IRawUtxo.safe` (the v2 plaintext has no Safe field),
`KeyPair.encrypt`, `KeyPair.decrypt`, `IShieldedOwner.encrypt` and `.decrypt`, and from `/internal`
`sealUtxoEnvelope`, `openUtxoEnvelope`, `scopenUtxoEnvelope`, `sealDecoy`, `looksLikeXWingEnvelope`,
`paddingMode` and `PaddingMode`. These consumers call them and must port before they take this SDK:
safe-sdk (key and Safe accounts, recovery, OTC), the relayer (fee UTXOs), issuer-sdk
(`encryptWithViewer` and `decryptWithViewer`, its tests), testenv (its scans, fixtures and OTC
sizes) and snap-demo (`note-reader.ts`).

### BREAKING: no issuer copies

A settlement publishes nothing for an issuer. `IExtData` and the recovery ext data drop
`issuerCopies` (the transact selector is `0x400517a6`); a keyed lane's issuer signs a lane-masked
receipt instead, over the chain, pool, lane token, sender, the lane's outputs, the validity window
and the issuer-held flag, through `/sign` v2, which shows it its own lane's outputs alone. Each OTC
leg asks its own lane's issuer in `pack`, and a swap's padding derives from a secret its two
parties draw (a share without `padSalt` is refused). Gone: `issuerCopyHash`, and from `/internal`
`buildLaneIssuerCopy`, `decoyIssuerCopy`, `decryptIssuerCopy`, `issuerCopyLength`,
`packIssuerPlaintext`, `packLaneIssuerCopy`, `ISSUER_COPY_LABEL` and `ByteSource`. Ports: the
relayer (transact decoding), compliance-engine and issuer-sdk (`/sign` v2, receipts), safe-sdk
(recovery receipts).

### BREAKING: `chainState` is `indexer`

`IConfig.chainState` is `IConfig.indexer`, read under `<base>/indexer/...` alone; a preset naming a
release before v0.3.3 finds no indexer there and is read over RPC. Port: private-safe-demo.

### BREAKING: the viewer root is not clamped

`KeyPair`'s viewer root, its X-Wing seed and the recovery salt's input, is `blake2s(spend key)`
without the Curve25519 clamp it kept from X25519. Every shielded address and viewing key of a given
key differs from v0.3.2's, and so do its recovery bindings and, bound to a recovery Safe, its owner
commitment. Regenerate: testenv's `FEE_TREASURY_SHIELDED_ADDRESS` and the pool fixtures it proves.

### Added

- The `eez-rollup-x` preset (the EEZ-X L2, chain 696990). `keyedValidity`,
  `KEYED_DEFAULT_WINDOW_BLOCKS` and `KEYED_MAX_WINDOW_BLOCKS`: a spend with a keyed lane proves under
  a window its issuer signs. On `/internal`: `RECOVERY_RECEIPT_DOMAIN`, `receiptDomain`,
  `verifyIssuerReceipt`, `issuerSignRequest`, `IIssuerSignRequest`, `ReceiptKind`,
  `MAX_ISSUER_ENVELOPE_BYTES` and `isIssuerEnvelope` (an issuer envelope is at most 4,096 bytes,
  sent and read; issuer `/utxos` reads follow its pages).
- `MerklePath.directions`, on every path `LeanMerkleTree.path` returns: the lean directions the
  circuits read, bit k set when the node is the right child at the k-th level that has a sibling.
- `SenderTree` is a `RegistryTree` whose empty leaf is 0, and gains its `leaf`, `set` and `clone`.
  `RegistryTree`'s constructor and `accountRegistry.registryZeros` take an optional empty leaf
  (`REGISTRY_EMPTY_LEAF` by default).

- On `@bermuda/sdk/internal`, one definition of each shared helper: `hex32`, `hkdfSha256`, `sum`,
  `apiHeaders` and `buildOtcExtData` (the ext data that is zero but `encryptedOutputs`, which a
  recovery batch hashes too).
- UTXO envelope v2 (HPKE, RFC 9180, over X-Wing) on every pool: K slots in front of
  `encryptedOutputs[0]`, one 512 + 32c byte body per output, every pad a real body. On `/internal`:
  `openUtxoV2Proof`, `openUtxoV2Detached` (under the commitment a channel names or the first of a
  proof's it rebuilds, one slot at most, returning that `slot`), `utxoV2InfoOf`,
  `sealUtxoOutputsV2`, `encryptedOutputsV2` (what one sealed proof publishes), `utxoV2SlotCount`,
  `otcLegSlots` (the slots one OTC leg seals to) and `UTXO_V2_MAX_DETACHED_LENGTH` (1,888 B: one
  slot and the widest body). `IShieldedOwner.previousViewers`, `ICommitmentEvent.txHash`,
  `IOtcPreludeShare.utxoSlots`.
- `viewerSeed` on `ITransactInputs` and `IOtcPreludeParams`: the spender's 32-byte viewer seed, for
  a spend whose handles are read-only (a Safe's D). `prepareUnsigned`, `prepareTransact`,
  `prepareWithdraw`, `preparePublicWithdraw` and OTC `prelude` take it; it is checked against the
  handle's viewer key and used for the call alone.
- On `@bermuda/sdk/internal`: `aggregate3` and `aggregate3Results`, a Multicall3 batch encoded and
  decoded, and `bundleRevert`, the revert data of the call that failed a bundle.
- `bundlePayloads` on `@bermuda/sdk/internal`, so `@bermuda/safe-sdk` bundles a group migration's
  payloads as the SDK bundles a chunked plan's.
- A contract depositor that sends its own deposit (safe-sdk's Safe) pays `options.relayer`
  `options.relayFee` on top, with no `DepositAuthorization`; an EOA's relayed deposit is unchanged.

### Changed

- License: FSL-1.1-ALv2 (was UNLICENSED). The registry proving windows are 20 s in Node and 30 s
  in a browser for every shape.
- `multiCall` is Multicall3: every preset but `eez-rollup-x` names its canonical address,
  `0xcA11bde05977b3631167028862bE2a173976CA11`, and a server's chain-config.json no longer
  overrides it. Several payloads bundle into one `aggregate3` with `allowFailure` false, which
  lands them atomically, in order; pinned reads are one `aggregate3`. `MULTICALL_ABI` is that
  function alone. Multicall3 reverts a bundle as `Multicall3: call failed`, so `relay` replays a
  reverted bundle with every call allowed to fail, and re-proves it when a call missed its period.
- The npm package no longer ships `scripts/` or `progress.md`. The scripts are tools for working on
  this repository (the ABI sync, test envelopes and the UTXO envelope v2 known answers with their
  stdlib-Python checker, the README badge and the keyed-URL check); run them from a checkout. `scripts/prove-harness.mjs`, which could not load, is deleted, and so is
  `progress.md`, notes that are not about this package.
- `accountRegistry.WITHDRAW_PAYEES` is typed `number`, the type `WITHDRAW_PAYEES` from
  `@bermuda/sdk/internal` has always had, instead of the literal type `16`. Its value is still 16;
  code that relied on the literal type no longer compiles.
- A transact or withdrawal proof of a shape no circuit has throws
  `no <kind> circuit for <n> inputs and <m> outputs` instead of a `TypeError`
  (`proofMap[...] is not a function`).
- `SenderTree.path` throws for an index outside the tree, as `RegistryTree.path` does. Both say
  `index <i> is outside a depth-<n> tree`, where the registry tree said `registry index <i> ...`.
- `utf82bytes` refuses a string with a lone surrogate, as ethers' `toUtf8Bytes` did for a memo,
  rather than encoding U+FFFD; `sumAmounts` sums anything with an `amount`.
- A proof's inputs are sorted by nullifier (a withdrawal keeps its first) and its outputs by
  commitment. `selectCircuitShape` takes the slots a proof needs. `buildAssembly` takes the pool's v2
  info and `assertCounterpartyTerms` the pool.
- The 4x8 shape carries 3 + 2·fee slots (`utxoV2SlotCount`): per OTC leg its counterparty's and,
  with the pool's fee on, the treasury's, and one relayer slot per swap. The leg that pays a relay
  fee seals its relayer UTXO to it; without one it is a pad drawn from the swap's padding secret,
  so a swap's bytes do not show a relay fee, and a plain transfer on 4x8 carries the same K. A
  fee-free swap is 20,356 calldata bytes.
- `assertOtcTradeSound(spender, self, counterparty, config)` takes the SDK config and checks the
  issuer-held rule (`assertShareIssuerHeld`), which `otc.pack` checked beside it: a Safe's quorum
  no longer approves a share whose receive body is a decoy on a token no issuer holds.
- `assertCounterpartyTerms` refuses a receive UTXO sealed to a slot its share does not publish, and
  a detached form of more than one slot.
- `IOtcPreludeShare.utxoSlots` is required: a share publishes its leg's slots.
- `IPayload.feeUtxos` and a relay request's `feeUtxos` carry v2 detached forms (`enc ‖ body`, or a
  bare body).
- A spend whose handles are read-only throws without `viewerSeed` (`needs its viewer seed`), and
  with a seed that is not the spender's (`not the spender's viewer seed`).
- `findUtxos` and the transact builders bind a UTXO's keys to the pool the call names (`pool`), not
  to `config.pool` whatever the call names.

### Removed

Exports with no caller in this package or in any of its consumers (safe-sdk, issuer-sdk, relayer,
compliance-engine, private-safe-demo, safe-server, x402-sdk, testenv, infra and deployments):

- From `@bermuda/sdk`:
  - `registryRootFor`. It returned `BigInt(await registry.publishedRoot())`; call that.
  - 22 types: `DepositInfo`, `HashStep`, `IBermudaPool`, `IComputeStealthKeyOptions`,
    `IDepositConfirmOptions`, `IDepositConfirmParams`, `IDepositInspectParams`,
    `IDepositProposeOptions`, `IDepositProposeParams`, `IGenerateStealtAddressOptions`,
    `IIndexedMerkleInputs`, `InspectResult`, `IPermitPayload`, `IQuoteExactInputSingle`,
    `IQuoteExactOutputSingle`, `IStealthAddressArtifacts`, `IStealthMetaKeys`, `IStorageModule`,
    `ITransactResult`, `ITransferDetails`, `TransferInfo` and `WithdrawInfo`.
- From `@bermuda/sdk/internal`: `_debug`, `difference`, `floor`, `log2`,
  `legacyKeccakHashUtxoMemo` (the pre-Poseidon memo hash, `keccak256(memo) % BN254_FIELD_SIZE`) and
  `publishedUtxoServiceUrl`.
- `LeanMerkleTree`: the methods `proof`, `getTreeEdge`, `getTreeSlices` and `serialize`, and the
  static `deserialize`.
- `IExtData.nonce` and `.nonceKey`: neither the pool's `ExtData` nor the ext-data hash has them.
- `IRecoveryExtData`: a recovery batch hashes `buildOtcExtData`'s ext data, as the pool does
  (safe-sdk ports its recovery hash to it).
- Duplicates of one helper: `accountRegistry.accountSlotsFor` and `accountRegistry.spendAuthSlotsFor`
  (`laneCountForShape`: the circuits size both by `N_LANES`) and, from `/internal`, `OS2IP` (an
  alias of `bytes2bigint`) and `METER_SLOTS` (`N_METER`).

### Fixed

- `getConfig(slug, { artifacts })` with the caller's own `artifacts` overlays no chain-config.json:
  a browser fetched the preset's synchronously from a host the caller had replaced, and took that
  deployment's addresses for every key the caller left unset. The overlay names the pool, the
  gateway and the burner delegate, so it is read only from the preset's own host; a caller with
  its own deployment passes its addresses.
- An SDK instance's `getTransactProof` is bound to its core, like the proof methods beside it.
  Called as `sdk.getTransactProof(...)` or detached, without a precomputed lanes fragment, it
  threw a `TypeError` instead of proving.
- `preparePublicWithdraw` refuses a deposit-id slot that has a public delta and no deposit id, as
  its error message says; the check it had could never fire. The slots come from a builder that
  already refuses a deposit component without an id, so no withdrawal that passed before fails now.
- A sponsored `stealth` with a `relayFee` refuses a missing or zero `relayer`. The pool pays a fee
  whose relayer is 0 to its caller, which for a sponsored bundle is the burner, so the fee went back
  to the burner and the relayer that sent the bundle went unpaid.
- An account's move from a rotated-out identity to its current D is sealed to a slot under the
  current identity's viewer key. It was sealed on the spending identity's OVK path, which the
  current identity's handle does not hold, so the moved value never showed up in its scans.

## `v0.1.0-rc0`

2026-03-22 | SDK prerelease primarily for a testnet deployment on Base Sepolia.
