# Security

## Reporting a vulnerability

Email **ops@bermudabay.xyz** privately. Do not open a public issue, pull request or discussion for
a suspected vulnerability. Include the affected version or commit, the module and function, and a
reproduction or proof of concept if you have one. We will acknowledge the report, keep you informed
while we fix it, and credit you if you wish.

## Security model

### Scope

In scope: this repository's `src/` and the committed `build/` that consumers import. The model below
centres on the modules that hold keys, signatures and envelopes, and on the formats the circuits and
the pool re-check:

| module                            | holds                                                                            |
| --------------------------------- | -------------------------------------------------------------------------------- |
| `keypair.ts`                      | key derivation, the owner commitment, the shielded address, key export           |
| `grumpkin-schnorr.ts`             | RFC 9380 hash-to-field, Schnorr over Grumpkin, the domains                       |
| `nullifier.ts`                    | the owner opening, the note keys, the claw keys, the nullifier                   |
| `xwing-xchacha20-poly1305.ts`     | X-Wing transport envelopes, HPKE, the UTXO envelope                              |
| `utxo.ts`                         | the commitment, the nullifier, the note plaintext, sealing and opening           |
| `output-encryption.ts`            | the check that an output ciphertext delivers its verified note                   |
| `issuer-policy.ts`                | an issuer's receipts and sealed transport, the claw commitments and pulls        |
| `anysigner.ts`                    | the signer abstraction                                                           |
| `safe-signatures.ts`              | Safe `signatures` blobs                                                          |
| `auth-data.ts`                    | transact's 4th argument: vouchers, deposit relay authorizations, dox withdrawals |
| `primitives.ts`, `utxo-format.ts` | Poseidon2, HKDF, I2OSP, the ext-data hash, the memo hash, the commitment fold    |

Out of scope, reported to their own repositories or maintainers: the circuits (`shtx-circuits`),
the contracts (`pool`), Safe-linked accounts (`@bermuda/safe-sdk`), the relayer, indexer,
compliance engine and issuer services, and third-party libraries.

### Actors and trust

- **The user's runtime** is trusted: its CSPRNG (`randomBytes`, from `@noble/hashes`, which reads
  `crypto.getRandomValues`), its memory, the wallet that signs the key-derivation message and the
  origin that asks for it.
- **A sender** is untrusted by its recipient. It can publish any bytes as `encryptedOutputs`; a
  recipient accepts a note only if its plaintext decodes canonically and rebuilds the commitment on
  chain (`utxo.ts` `acceptUtxo`).
- **A relayer** is trusted for liveness only. The proof binds the external data through
  `extDataHash`, which the pool recomputes, so a relayer cannot alter recipient, amounts or fees.
  `relay` resolves only on a transaction the chain shows to be the one submitted (target, calldata,
  value, EIP-7702 authorizations; `relay.ts` `delivered`), so neither a relayer nor a relay-queue
  result can pass off another transaction's hash as the relay's.
- **RPC nodes and the indexer** are trusted for liveness and see the queries they serve. They are not
  trusted for value: the pool accepts only roots it knows (`MerkleTreeLib.areKnownRoots`), so a spend
  of a commitment they invented fails on chain. One exception is a vaulted class's index, which prices
  an amount stated in underlying units into shares: the SDK checks that it matches the class's assets
  per share, but a node that falsifies both is not caught, so state vaulted amounts in shares
  (`units: 'shares'`) when the nodes are not trusted.
- **The compliance engine and issuers** sign under their own Schnorr domains: the engine its deposit
  attestations (`compliance.ts` `signDepositAttestation`) and fee-rate grants. The SDK checks an
  issuer's signature over its X-Wing key record and its receipts (`issuer-policy.ts`
  `verifyIssuerKemKeys`, `verifyIssuerReceipt`).
- **A recovery Safe** can recover a single key's UTXOs only with its ERC-1271 approval and the
  recovery salt, which derives from the viewer secret. Its address is sealed in the owner's, which
  is one on every chain, so it must answer ERC-1271 at that one address on every chain where the
  owner holds funds (deploy it there everywhere: CREATE2, same owners and salt). `account()` checks
  its code on the configured chain only, refusing one without code there unless the caller names it
  counterfactual (`recoverySafeCounterfactual`): on any other chain, no Safe, or other code, at that
  address leaves the owner's funds there unrecoverable, or a recovery's approval to whoever controls
  that code.
- **The registry's deployer key** places the registry core at one address on every chain: its
  CREATE3 address under the key and `ACCOUNT_REGISTRY_VERSION` (pool `DeployAccountRegistry`), which
  does not depend on the code deployed. On a chain where the core is not yet deployed, that key
  decides what code takes the address that Safe-linked accounts' ids and D already name.

### Key hierarchy

```
wallet ── EIP-712 signature over KeyDerivation { purpose: 'bermuda:account:v1', id } by an EOA,
          taken as 65 bytes r ‖ s ‖ v with low s and v 27/28
          domain { name: 'Bermuda', version: '1' }   no chain, no pool: one account on every chain
  └ spend key   s = hash_to_field(sig, DST 'bermuda:sk-spend:v1')        BN254 Fr, s ≠ 0
    ├ spend pubkey P = s·G on Grumpkin; spendKeyHash = Poseidon2(P.x, P.y)
    ├ viewer root   v = HKDF-SHA256(I2OSP(s, 32), salt ∅, 'bermuda:viewer-root:v1', 32)   the full viewing key
    │ ├ X-Wing seed   x = HKDF-SHA256(v, salt ∅, 'bermuda:xwing-seed:v1', 32)   the incoming viewing key
    │ │ └ X-Wing viewer key pair = XWing.KeyGen(x)    public key 1216 B
    │ ├ note secret   r = hash_to_field(HKDF-SHA256(v, salt ∅, 'bermuda:nk-identity:v1', 32) ‖ I2OSP(core, 32),
    │ │                   DST 'bermuda:nk:identity:v1') in Grumpkin's scalar field, r ≠ 0: one per identity (core)
    │ │ ├ note key    R = r·G on Grumpkin, in the address
    │ │ └ self tweak  t = hash_to_field(I2OSP(r, 32) ‖ I2OSP(rho, 32) ‖ I2OSP(blinding, 32), DST 'bermuda:nk:self-tweak:v1')
    │ ├ recovery salt = hash_to_field(v, DST 'bermuda:recovery-salt:v1')   BN254 Fr, ≠ 0
    │ ├ UTXO cache key = HKDF-SHA256(v, salt ∅, 'bermuda:utxo-cache:v1', 32)
    │ │                  sealing with aad = 0x01 ‖ info ‖ the storage key
    │ └ UTXO cache id  = HKDF-SHA256(v, salt ∅, 'bermuda:utxo-cache-id:v1' ‖ info, 32)   stored in clear
    │                    info = 'bermuda:utxo:v1' ‖ I2OSP(chainId, 8) ‖ pool: one cache per chain and pool
    └ burner key    = Blake2s-256('bermuda:burner-account:<chainId>:<pool>:<id>:v1' ‖ I2OSP(s, 32))   secp256k1,
                      one per chain and pool (chainId in decimal, pool in lower case)

recoveryHash = Poseidon2(safe, salt, minDelay)   (minDelay 0: the pool's time lock only; 0 when unbound)
core         = Poseidon2(KEY_CORE_TAG, spendKeyHash, recoveryHash)
ownerId      = Poseidon2(OWNER_TAG, core, R.x, R.y)
address      = I2OSP(core, 32) ‖ I2OSP(R.x, 32) ‖ I2OSP(R.y, 32) ‖ X-Wing public key     1312 B, 2624 hex
               written in its checksum case: hex letter i upper case iff nibble i (high nibble first) of
               SHAKE-256(the ASCII of its lower-case hex body, 2624 B without 0x; 1312 B out) is ≥ 8; read in one
               case unchecked, refused in any other mix of case
```

Per note, its payer draws a tweak `t` (its own outputs, which this device proves, take the self tweak) and
commits to the key point `P = t·R`; the owner's nullifier key is `nk = t·r mod q`, so `P = nk·G`. A keyed token's
issuer derives each note's claw key from the note's key point, `c = hash_to_field(issuerSeed ‖ chainId ‖ pool ‖ token
‖ P.x ‖ P.y, DST 'bermuda:claw-key:issued:v1')` (`nullifier.ts` `issuedClawKey`), and keeps nothing. The note commits
to `ck = Poseidon2(CLAW_KEY_TAG, c)` and its nullifier hashes `c`:

- the payer asks `/assign` for each output's `ck` by its key point and seals `ck` beside the tweak; it never learns
  `c`, so neither it nor anyone it shows the note to (a Safe deposit's co-signers) computes the payee's nullifier;
- the owner pulls `c` from `/claw-keys` with a Schnorr signature by `nk` over the pull (`issuer-policy.ts`
  `signClawKeyPull`, `pullClawKeys`), and checks that `c` opens `ck`. Only the owner holds `nk`: the payer holds `t`
  and `R`, not `r`. Its own outputs are pulled the same way. A note whose `c` has not come is received but not
  spendable (`Utxo.awaitsClawKey`, `ClawKeyWithheldError`);
- the issuer recognises the note's spend and claws it back, as before, and can withhold `c`, which freezes the note:
  the power its clawback already gives it;
- a spend claims each keyed input at `/sign` with a Schnorr signature by its `nk` over the receipt the request asks
  for, joined to the input's commitment and nullifier (`issuer-policy.ts` `signIssuerSpend`), so the issuer keeps
  outputs only for a spend of a note it issued, whose spender holds its key. A keyless input is never named: its
  issuer cannot link its nullifier.

⚠ Whoever sees both the tweak and the nullifier key of one note learns `r`: a note's nullifier key goes to
another prover only when this device proved the transaction that created it (`Utxo.delegable`). Its tweak is then
the self tweak, which no payer knows but the note's plaintext carries, so an incoming viewing key reads it (Known
limitations).

The derivations are `KeyPair.deriveAccount`, `KeyPair.fromSeed`, the `KeyPair` constructor, `computeRecoverySalt`,
`computeRecoveryBinding` (`keypair.ts`), `deriveBurnerKey` (`account.ts`), and the keys under the viewer root in
`nullifier.ts`. A Safe-linked account's owner commitment is its `D = Poseidon2(OWNER_TAG, core, R.x, R.y)` over its
account core, and each identity has its own note secret, which `@bermuda/safe-sdk` holds; each of its viewer
generations' secrets plays the viewer root's part (`viewerRoot`, `previousViewerRoots` on its handle). This SDK takes
an X-Wing seed a handle lacks as `viewerSeed` and refuses one that does not derive the handle's viewer key (`utxo.ts`
`viewerSeedOf`).

### Invariants

Each formula below must equal the circuits'; a mismatch is a proof that does not verify or a UTXO
nobody can spend. Circuit paths are in `shtx-circuits`, contract paths in `pool`.

1. **Owner commitment**: `ownerId = Poseidon2(OWNER_TAG, core, R.x, R.y)` with `core =
Poseidon2(KEY_CORE_TAG, Poseidon2(P.x, P.y), recoveryHash)` (an account's: `Poseidon2(ACCOUNT_CORE_TAG,
Poseidon2(accountId, dr), recoveryHash)`), recomputed from the current opening and never stored. SDK:
   `computeKeyCore`, `computeOwner`, `KeyPair.ownerId`, `account-registry.ts` `computeDestination`. Circuit:
   `crates/common/src/notes.nr` `compute_key_core`, `compute_owner`; `account.nr` `compute_destination`.
2. **Recovery binding**: `Poseidon2(safe, salt, minDelay)`, one arity for every owner, with
   `0 <= minDelay < 2^32`; `minDelay = 0` leaves only the pool's time lock. SDK: `computeRecoveryBinding`.
   Circuit: `notes.nr` `compute_recovery_binding`.
3. **Commitment**:
   `C = Poseidon2(dom, amount, ownerId, blinding, tokenId, memoHash, subHash, rho, P.x, P.y, ck)`, with
   `dom = Poseidon2(NOTE_COMMITMENT_TAG, chainId, pool)`, `P = t·R = nk·G` the note's key point,
   `ck = Poseidon2(CLAW_KEY_TAG, c)` on a keyed token's note and 0 otherwise, `rho` one of the creating
   proof's input nullifiers, `subHash = Poseidon2(ids[8] ‖ amounts[8])`, `memoHash = Poseidon2(len,
packed[9])` (31 memo bytes per field) and `tokenId` the token, or the token + 2^160 for its vaulted
   class. SDK: `nullifier.ts` `noteDomain`, `keyPoint`, `clawCommitment`; `utxo-format.ts`
   `computeCommitment`, `computeMemoHash`; `Utxo.getCommitment`, which throws until `rho` and the key are
   set. Circuit: `notes.nr` `compute_note_domain`, `compute_output_key_point`, `compute_key_point`,
   `compute_claw_commitment`, `compute_commitment`, `compute_subutxo_hash`.
4. **Nullifier**: `Poseidon2(NULLIFIER_TAG, s, C)`, `s = c` on a keyed note and `nk` otherwise, so only
   the owner computes a keyless note's (never its payer), and a note has exactly one. SDK: `nullifier.ts`
   `noteNullifier`, `nullifierKey`; `Utxo.getNullifier`, which throws without its secret. Circuit:
   `notes.nr` `compute_nullifier`. The pool refuses a spent one: `src/libraries/CoreLib.sol`
   `spendNullifiers`.
5. **Spend authorization**: each spend-auth slot signs its slot message under the spend-auth domain,
   a single key directly and a Safe-linked account's owners in counted approvals over it. The slot
   message is `shtx_hash` on a shape with one slot, and on transact_4x8, the one shape with two,
   `Poseidon2(SLOT_AUTH_TAG, shtx_hash, mask)`, where bit `i` of `mask` is set when input `i` is real
   and names the slot. Each signature covers exactly the inputs at the positions it names: every input
   of the proof on a one-slot shape, on transact_4x8 those that name its slot. The circuit refuses
   one party on both of transact_4x8's spending slots, an account by its accountId and a key by its
   pubkey hash, so two slot messages of one party over one `shtx_hash` never settle together. A
   swap's signer still signs no swap on a one-slot shape, whose one signature covers every input on
   its slot (A swap's packs, below). SDK: `KeyPair.sign`, `account-registry.ts`
   `spendAuthMessage`, `signAuth`; `otc.ts` `buildAssembly`, `assertOtcTradeSound`. Circuit:
   `crates/common/src/account_auth.nr` `slot_messages`, `verify_spend_auth`, `verify_account_auth`;
   `shtx.nr` `verify_shtx`.
6. **`shtx_hash`** binds the chain id, the pool, the roots, the nullifiers, the commitments, the public
   amount, the recipient, `ext_data_hash` and the validity window. SDK: `fee-rate.ts` `shtxHashOf`. Circuit:
   `crates/common/src/shtx.nr` `compute_shtx_hash`.
7. **External data**: `extDataHash = keccak256(abi.encode(ExtDataCore)) mod p`. SDK: `primitives.ts`
   `getExtDataHash`. Pool: `src/libraries/CoreLib.sol` `assertExtDataHash`.
8. **No key leaves by accident**: `toJSON` writes the address; a full viewing key is written only for
   a key with a recovery binding, and the spending key only when named. SDK: `KeyPair.toJSON`,
   `serialize`, `deserialize`. Client only.
9. **A received note is counted** only when its plaintext decodes canonically and rebuilds its
   commitment under this pool's `dom`: the owner from its core and note key, the key point from its tweak
   (`t·R`), and the claw commitment as the plaintext carries it, so a payer that withholds the tweak pays
   a note no opener finds; and when the owner's `nk = t·r mod q` is a field element. A keyed note is
   spendable once its issuer released a claw key that opens its claw commitment. SDK: `utxo.ts`
   `utxoOfPlaintext`, `acceptUtxo`, `Utxo.deriveNk`, `Utxo.setClawKey`. Client only. A note's nullifier key
   goes to another prover only when this device proved the transaction that created it (`Utxo.selfProved`,
   `delegable`): its tweak is then this device's self tweak.
10. **The spender's own outputs** are sealed under its viewer seed, never into a slot. SDK:
    `sealUtxoOutputs`. Client only.

The domain and tag values are pinned to the circuits' literals in `test/grumpkin-vectors.test.ts`,
and the suites built on `test/helpers/circuit-harness.ts` execute SDK-built witnesses against the
vendored circuits. `test/fixtures/shtx-kat.json` pins `shtx_hash`, the auth digest, `D`, the identity
commitment, the recovery binding and the nullifier, and beside them meter note ciphertexts, receive
leaves, class-index leaves and the rounded-up values of a payment in another unit and of a flipped
output in its lane's unit, with values that `scripts/gen-shtx-kat.mjs` derives from the circuits' and
the pool's spec without `src/`; `test/fixtures/nf-kat.json`, shtx-circuits' own, pins the owner
openings, the note keys, the commitments and the nullifiers.

These are tests, not proofs: the formal-verification board
([`BOARD.md`](https://github.com/BermudaBay/fv/blob/main/BOARD.md) of BermudaBay/fv) leaves the SDK
out for now. Beyond the known answers above, `test/circuit-differential.test.ts` runs the circuits'
`crates/common` as an oracle (`test/oracle/`, a Noir program pinned to shtx-circuits `1b5cdb0a`) on
random inputs and compares Poseidon2, the owner id and recovery binding, the memo hash, the
commitment and nullifier, `shtx_hash` and Schnorr verdicts with the SDK's; `test/property-*.test.ts`
are fast-check property tests of the keys, Schnorr, UTXOs, X-Wing and the signers; and
`test/wycheproof-vectors.test.ts` and `test/kem-accumulated.test.ts` run official vectors through
the SDK's own crypto (Wycheproof ML-KEM-768, X25519, (X)ChaCha20-Poly1305, HKDF-SHA256 and secp256k1
ECDSA; accumulated ML-KEM-768 vectors as the Go standard library publishes them, and X-Wing ones
computed with CIRCL).

### Schnorr over Grumpkin

`grumpkin-schnorr.ts`. Grumpkin is `y² = x³ − 17` over the BN254 scalar field, generator `(1, Gy)`,
order `N` (the BN254 base field). A signature is `R.x ‖ R.y ‖ z` (96 bytes; the circuit takes
`[R.x, R.y, z_lo, z_hi]`) with `c = Poseidon2(R.x, R.y, P.x, P.y, m, domain)` and `z = k + s·c mod N`,
the construction of the `BermudaBay/schnorr` Noir library the circuits use.

- The message is 32 bytes and a field element; the domain is a field element.
- The nonce `k` is hedged (`hedgedSchnorrNonce`): 48 bytes of HKDF-SHA256 over
  `I2OSP(s, 32) ‖ m ‖ I2OSP(domain, 32)`, salted with 32 fresh CSPRNG bytes, info
  `'bermuda:schnorr-nonce:v1'`, mapped into `[1, N)` as `x mod (N − 1) + 1` (noble's `mapHashToField`).
  A weak or repeating CSPRNG then repeats a nonce only for the same key, message and domain, which signs
  the same signature. 32 bytes would leave a modulo bias at statistical distance 0.039, which a lattice
  attack over enough signatures turns into the key. Signing refuses `c ≡ 0` and `z = 0`.
- Verification refuses `z = 0`, `z ≥ N`, `c ≡ 0`, and an `R` or `P` off the curve or at infinity
  (`pointFromBytes`).

Every domain is `hash_to_field(message, DST 'bermuda:schnorr-domain:v1')`, so no signature of one
purpose passes as another's:

| message                                  | constant                                | circuit constant                     |
| ---------------------------------------- | --------------------------------------- | ------------------------------------ |
| `bermuda:shtx:spend-auth:schnorr:v1`     | `SHTX_SPEND_AUTH_DOMAIN_FIELD`          | `SCHNORR_DOMAIN`                     |
| `bermuda:issuer:receipt:schnorr:v1`      | `ISSUER_RECEIPT_DOMAIN_FIELD`           | `RECEIPT_SCHNORR_DOMAIN`             |
| `bermuda:fee-rate:schnorr:v1`            | `FEE_RATE_DOMAIN_FIELD` (`fee-rate.ts`) | `FEE_RATE_SCHNORR_DOMAIN`            |
| `bermuda:deposit-attestation:schnorr:v1` | `DEPOSIT_ATTESTATION_DOMAIN_FIELD`      | `DEPOSIT_ATTESTATION_SCHNORR_DOMAIN` |
| `bermuda:issuer:kem-key:schnorr:v1`      | `ISSUER_KEM_KEY_DOMAIN_FIELD`           | none: off-chain key record           |
| `bermuda:claw-key:pull:v1`               | `CLAW_KEY_PULL_DOMAIN_FIELD`            | none: off-chain pull, by `nk`        |
| `bermuda:issuer:spend:schnorr:v1`        | `ISSUER_SPEND_DOMAIN_FIELD`             | none: off-chain spend claim, by `nk` |

A Safe-linked account's owners sign their counted approvals under the spend-auth domain on purpose
(`account-registry.ts` `signAuth`); `bermuda:shtx:owner:v1` is the tag `OWNER_TAG`, not a Schnorr
domain. `ADDR_BIND_DOMAIN_FIELD` (`bermuda:shtx:addr-binding:schnorr:v1`) is pinned by the vectors
only: neither the circuits nor the SDK sign or verify under it.

### Envelopes

`xwing-xchacha20-poly1305.ts`. X-Wing is the ML-KEM-768 + X25519 hybrid KEM: what it seals stays
confidential while either half holds. There is no X25519-only fallback.

**Transport envelope** (Safe owner transport; labelled variants for the issuer transport):
`xnonce(24) ‖ kemCt(1120) ‖ ciphertext ‖ tag(16)`, with
`key = HKDF-SHA256(ss, salt ∅, info = label ‖ kemCt ‖ pk)` and XChaCha20-Poly1305 under a random
`xnonce`, the AAD being `xnonce ‖ kemCt ‖ extraAad`. A labelled envelope must use its own non-empty
label (`sealLabelled`, `purposeInfo`).

**UTXO envelope**, one per proof: K X-Wing slots in front of `encryptedOutputs[0]` and one body
of `640 + 32c` bytes per output, the plaintext and the tag (one memo class `c ≤ 8` per proof).

```
info  = 'bermuda:utxo:v1' ‖ I2OSP(chainId, 8) ‖ pool(20)
slot  = enc of RFC 9180 SetupBaseS(pkR, info): KEM 0x647a (X-Wing), HKDF-SHA256, AEAD 0xFFFF (export only)
k_i   = ctx.Export('bermuda:utxo:out:v1' ‖ SHA-256(enc ‖ pkR) ‖ I2OSP(|body|, 2) ‖ I2OSP(C_i, 32), 32)
k_i   = HKDF-SHA256(ikm seed, salt 'bermuda:utxo:ovk:v1',
                    info 'bermuda:utxo:out:v1' ‖ info ‖ I2OSP(|body|, 2) ‖ I2OSP(C_i, 32))    own outputs, pads
body  = ChaCha20-Poly1305(k_i, nonce 0^12, aad 'bermuda:utxo:v1' ‖ I2OSP(C_i, 32), plaintext_i)
```

- The zero nonce is safe only because every key is single-use: `k_i` is bound to chain, pool,
  body length and the commitment, which binds the plaintext. Never seal two plaintexts under one
  `(key, C, |body|)`.
- Per-output keys are exported, not sealed with HPKE's AEAD: RFC 9180 §9.7.1 makes `Open`
  order-dependent, and outputs are sorted, interleaved across a swap's legs and travel detached.
- ChaCha20-Poly1305 is not key-committing, so a body that opens is not yet a note: the acceptance
  rule above decides.
- K follows from public proof data, dummy slots are real encapsulations, pads are real amount-0
  bodies, and slots, inputs and outputs are sorted, so the calldata does not tell a pad from an
  output or which outputs share a recipient. A scan costs at most 16 decapsulations per viewer and
  header (`scanUtxoLeaves`).
- The note plaintext (`utxoPlaintext`) is
  `core(32) ‖ R.x(32) ‖ R.y(32) ‖ token(20) ‖ blinding(32) ‖ rho(32) ‖ tweak(32) ‖ clawCommitment(32) ‖
ids(8×31) ‖ amounts(8×16) ‖ memoLen(2) ‖ memo`, zero-padded to `624 + 32c` bytes; encoding throws rather than
  truncate. Every field reaches the commitment, so one body opens to at most one note for every opener. It never
  carries `nk` or a claw key: it reaches the payer too.

**Meter note ciphertext** (`meters.ts` `sealMeterNote`), one per meter note a proof inserts:
`nonce(24) ‖ ciphertext(192) ‖ tag(16)`, XChaCha20-Poly1305 over the note's six fields under the
account's meter key `HKDF-SHA256(identity seed, 'bermuda:meter-ciphertext:v1')`, AAD
`'bermuda:meter-note:v1'`. The nonce is derived, not drawn:
`HKDF-SHA256(HKDF-SHA256(key, 'bermuda:meter-nonce-key:v1'), 'bermuda:meter-nonce:v1' ‖ plaintext, 24)`,
so every owner device that plans a step derives the same bytes and the same `meterCiphertextHash`
(`keccak256 mod p`). The construction is SIV-style: it reveals only plaintext equality, and no
plaintext repeats, since each note carries its own nullifier secret. The owners sign each real step's
`(nullifier, note, ciphertextHash)` (`meterBinding`) and the pool holds the ciphertext a slot inserts
to its hash, so a prover that is not the owner (an OTC counterparty) publishes exactly the ciphertexts
the account handed over (`handOverMeters`) and never holds the key. A cover step carries 232 random
bytes, unsigned.

**UTXO cache entry** (`utxo-cache.ts` `sealUtxoCache`), one per owner, chain and pool:
`0x ‖ hex(0x01 ‖ nonce(24) ‖ ciphertext ‖ tag(16))`, XChaCha20-Poly1305 under a random nonce and the
cache key above, over the cache's JSON (every cached UTXO's opening and the decrypt watermark). The AAD
is `0x01 ‖ info ‖` the full storage key `<storagePrefix>:utxos:<cache id>`, with `info` the UTXO
envelope's, which names the chain and the pool, so an entry opens only on its chain and pool, and only
where it was stored. The cache id names the entry instead of the address: reading the storage tells
neither whose entry it is nor what it holds. An owner without a viewer root (a read-only keypair, or
one zeroed on disposal) is refused before anything is read. An entry that does not open is dropped
and every leaf is decrypted again; one that opens is still checked: a stored commitment or nullifier
must be its opening's, and the watermark must be one a scan could have written. A plaintext entry an
earlier version left under the address, and an entry under a rotated-out viewer's id, is deleted on
the owner's first scan.

`test/fixtures/utxo-kat.json` is produced by a generator independent of `src/`
(`scripts/gen-utxo-kat.mjs`) and re-derived without noble by `scripts/check-utxo-kat.py`;
`test/fixtures/xwing-draft-vectors.json` is the X-Wing draft's own vector file.

### Signers

`anysigner.ts` wraps ethers signers, viem accounts and wallet clients, and ERC-1271 contract signers
(`ContractSigner`) behind one interface: `signMessage` is EIP-191, `signTypedData` is EIP-712, and a
contract signer signs the corresponding digest. `safe-signatures.ts` `encodeSafeSignatures` builds a
Safe `signatures` blob (owners ascending, ERC-1271 owners as `v = 0` with a dynamic part); the Safe
verifies it.

**Dox withdrawal.** The recipient signs the EIP-712 `DoxWithdrawal(bytes32 shtxHash)` of the
proof's trailing public input, `shtx_hash`, in the pool's domain
`{ name: 'BermudaPool', version: '1', chainId, verifyingContract: pool }` (`auth-data.ts`
`signDoxWithdrawal`). The pool accepts an ECDSA signature of that digest by the recipient's key,
else the recipient's ERC-1271 answer for it. The SDK signs with an ethers `SigningKey` (or a `Wallet`
exposing one), a `{ kind: 'safe' }` spec whose owners sign an EIP-712 `SafeMessage` of the digest, or
a caller-supplied callback, which receives the digest and the typed data: a wallet signs the typed
data with `signTypedData` and shows its signer the pool, the chain and the `shtx_hash` it authorizes.

**Burner batches.** A sponsored burner batch is the EIP-712
`Execute(uint256 nonce,uint256 deadline,uint256 minGas,bytes32 mode,bytes executionData)` in the domain
`{ name: 'BermudaBatchDelegate', version: '1', chainId, verifyingContract: burner }` (`account.ts`
`burnerAuthDigest`), which BatchDelegate's `executeWithAuth` recovers the burner from, at the burner's
next `nonce()` and until `deadline` (default: an hour past the latest block's timestamp). The relayer
picks the gas, so the burner signs `minGas`, below which BatchDelegate does not start the batch: the
`eth_estimateGas` of the burner's own `execute` of the batch, sent from the burner with a fresh
burner's EIP-7702 delegation, plus `executeWithAuth`'s overhead, plus 20% (`burnerMinGas`). A relayer
that starves the batch gets a revert, not a call of it that catches its own failure completing on its
failure branch. Nothing signed for `executeWithAuth` goes to the RPC node: an `Execute` in an estimate
would be valid, and whoever saw it could send it first with a starving gas limit.

### Cryptographic assumptions and references

| primitive                                                           | reference                                          | used for                                                                                                                       |
| ------------------------------------------------------------------- | -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| hash_to_field, expand_message_xmd (SHA-256, k = 128, L = 48, m = 1) | RFC 9380 §5.2, §5.3.1                              | spend key, note secrets, self tweaks, claw keys, recovery salt, Schnorr domains, tags; 0 maps to 1 (`hashToFieldScalar`)       |
| Poseidon2 over BN254 (`@zkpassport/poseidon2`)                      | as Noir's `poseidon2`                              | commitments, nullifiers, owner ids, Schnorr challenge; inputs checked `< p`                                                    |
| Grumpkin Schnorr                                                    | `BermudaBay/schnorr` (fork of `noir-lang/schnorr`) | spend authorization, receipts, attestations, fee-rate grants, issuer key records, claw-key pulls, spend claims                 |
| X-Wing (ML-KEM-768 + X25519)                                        | draft-connolly-cfrg-xwing-kem; FIPS 203; RFC 7748  | viewer and transport keys                                                                                                      |
| HPKE base mode, Export only                                         | RFC 9180 §5.1, §5.3                                | UTXO envelope slots                                                                                                            |
| HKDF-SHA256                                                         | RFC 5869                                           | viewer root and its subkeys, meter keys, transport keys, Schnorr nonces, the OVK path (HMAC as a dual PRF, as TLS 1.3 uses it) |
| ChaCha20-Poly1305; XChaCha20-Poly1305                               | RFC 8439; draft-irtf-cfrg-xchacha                  | UTXO bodies; transport envelopes, meter notes, the UTXO cache                                                                  |
| Blake2s-256                                                         | RFC 7693                                           | burner key                                                                                                                     |
| I2OSP                                                               | RFC 8017 §4.1                                      | every fixed-width integer encoding                                                                                             |
| EIP-712, EIP-191, ERC-1271                                          |                                                    | key derivation, dox withdrawals, burner batches, Safe messages, address links, contract signers                                |

Security rests on discrete log in Grumpkin, the collision and preimage resistance of Poseidon2 (and
its behaviour as a random oracle in the Schnorr challenge), the IND-CCA security of X-Wing (either
ML-KEM-768 or X25519), the AEAD security of (X)ChaCha20-Poly1305, SHA-256, HMAC and Blake2s as PRFs,
and the runtime's CSPRNG. Runtime dependencies are pinned exactly in `package.json`: `@noble/curves`,
`@noble/hashes`, `@noble/ciphers`, `@noble/post-quantum`, `@zkpassport/poseidon2`, `ethers`, `viem`,
`@noir-lang/noir_js` and `@aztec-foundation/bb.js`.

### What the circuits and the pool do not check

The circuits and the pool enforce value, ownership, spend authorization, nullifier uniqueness and
the binding of external data. They do not see, and nothing on chain re-checks:

- that `encryptedOutputs` are well formed, sealed to the right key, or openable at all; a sender
  can pay a note its recipient never finds;
- the unlinkability the envelope layout aims for (slot count, dummies, padding, ordering);
- the quality of randomness in blindings, padding keys, Schnorr nonces, X-Wing seeds,
  encapsulation coins and XChaCha nonces;
- that a recipient address is the recipient's: a UTXO to a wrong `ownerId` (for instance a bare
  `spendKeyHash`) is valid on chain and unspendable;
- how keys are derived, stored and exported.

### Known limitations

- **Deterministic signatures for key derivation.** The spend key is a hash of an EOA's ECDSA
  signature in its canonical form (low s, v 27/28), so the wallet must sign deterministically (RFC 6979,
  as ethers, viem and common wallets do); one that randomizes its nonces derives another key each time.
  `KeyPair.deriveAccount` refuses a contract signer and any signature that is not 65 bytes recovering to
  the signer, so a smart-contract wallet or a passkey derives no account key.
- **One account on every chain.** The EIP-712 domain names no chain and no pool, so one wallet and
  id are one account, with one shielded address, on every chain and pool. Whoever learns the
  address on one chain (a payer, an address link, which names one chain but carries the whole
  address) knows it on every other. One key-derivation signature is the account everywhere: a
  wallet that signs the `KeyDerivation` prompt for a phishing page gives away its account on every
  chain. A Safe-linked account is one D on every chain under one registry address; testnets and
  mainnets name different `ACCOUNT_REGISTRY_VERSION`s, or deploy from different keys, so they never
  share a registry address, an account id or a D. A burner names its chain and pool, so it links
  nothing across them. This is accepted: one private account on every chain is the design, and the
  prompt names no origin and carries no warning. An integrator asks for it only from its own origin,
  after a user action, and never forwards, logs or persists the signature; `{ seed }` and Safe-linked
  accounts have no such prompt.
- **Pre-X-Wing addresses.** Where a key's X25519 viewer public key was ever published, recovering
  that clamped secret opens the UTXOs sealed to it, and the viewer root of that era up to 5 bits:
  they are not post-quantum confidential. Today's viewer root, an HKDF of the spend key, does not
  follow from it.
- **Nullifiers before a spend lands.** A spend's nullifiers are known before it lands: to an OTC
  counterparty (the prelude share and the pack), the issuer's `/sign` service and the fee-rate source
  (the full preimage), a withdrawal's sponsor and the compliance engine it asks for the voucher (the
  first nullifier, `sponsorWithdrawTerms`), the relayer (the payload), and everyone once a submission
  reverts on chain. If the spend never lands, each of them can link the later spend of those notes;
  retry the same proof, or spend exactly those inputs to yourself.
- **JavaScript.** Secrets live in `bigint`s and `Uint8Array`s that cannot be reliably zeroized, and
  `bigint` arithmetic is not constant-time. Local side channels are out of scope.
- **Metadata.** RPC nodes, the indexer and the relayer see the queries and submissions they serve
  and the network addresses they come from.
- **Storage at rest.** Only the UTXO cache is sealed. Whatever runs with the app's storage and the
  viewer root (a script in the page's origin, the same OS user) reads it as the app does, so in a
  browser it is as private as the origin is isolated. Every key the SDK stores names its chain, and
  its pool where what it holds is the pool's (the UTXO cache's id and seal, the chain sync's rows),
  so chains and pools that share a `storagePrefix` share no cache, watermark or queued operation.
  The chain sync's rows are public chain data, stored in clear and checked against the chain's
  roots. `fileSystemStorage` writes its file with mode 0o600 through a rename; other providers
  (`config.storage`, `localStorage`) keep what they are given as the platform keeps it.
- **Slot checks.** `looksLikeXWingCiphertext` catches malformed slots, not dishonest ones: an
  encapsulation to any key passes.
- **A swap's packs.** Whoever holds both signed packs of an OTC swap can land it at any time up to its
  deadline (unix seconds, which the pool compares with `block.timestamp`), so every swap names one
  (`otc.prelude` refuses a swap without). Spending an input of one's own leg is the only way to cancel a
  pack already handed over. A pack's signature authorizes its own leg's inputs alone: on transact_4x8
  the circuit refuses one party on both spending slots, and on a one-slot shape the signer signs
  nothing. Two packs of one signer share an assembly only when each takes the signer's other share for
  the counterparty's; the circuit refuses their proof, whoever proves it. A one-slot shape has no second
  slot to compare, so before anything is signed `otc.pack` and `safe.otc` refuse a leg that buys the
  token id it sells and an assembly with fewer than two spend-auth slots.
- **Two roots of one tree mark a swap.** Each leg's inputs open at the root its prelude read, so a swap
  whose preludes read two states of one tree publishes two roots of it, which no other flow does: it
  marks the proof as a swap and gives the tree sizes its preludes read, not which leg read which. This
  is accepted: no value is at risk, and legs that read one tree publish one root.
- **A swap between a token's two classes.** A flip keeps a note's deposit ids, and a proof binds each
  deposit id to one token, so legs that both sell value of one deposit, one in each class, never prove:
  `buildAssembly` refuses them before anyone signs, naming the id. `otc.prelude` picks a leg's notes,
  so one side moves those notes into its other class first, or the swap sells notes of another deposit.
- **An issuer-held purchase.** When the counterparty sells a token whose issuer holds its UTXOs, the
  signer's payment is a decoy on chain, found only through that issuer, which keeps the envelope the
  counterparty's own pack sends it (`legReceipt`); nothing ties it to the share's envelope the signer
  checked. If it sends another, the swap lands, but the purchase is a note no scan of the signer's
  finds, whose opening the counterparty holds. Keep the counterparty share until the payment is
  found: its envelope opens for the signer, and `initFindUtxos(...).ingestIssuerUtxos`
  (`@bermuda/sdk/internal`) takes it once the swap lands.
- **Incoming viewing keys and OTC packs.** An incoming viewing key plus an OTC pack reveals the
  identity's note secret, so its holder sees every spend of that identity as a full viewing key would.
  It gains no spend or recovery authority, since each spend needs the spend key's signature over
  exactly the inputs it names. Give incoming viewing keys to auditors, never to swap counterparties.
