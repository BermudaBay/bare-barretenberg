# Third-party notices

`@bermuda/sdk` is licensed under BUSL-1.1 ([LICENSE](./LICENSE)). The parts below come from third
parties and remain under their own licenses.

## Circuit artifacts in `src/circuits/` and `build/src/circuits/`

The compiled circuit JSONs embed, in their `file_map`, the Noir sources they were compiled from. Besides
Bermuda's own circuits, those sources include:

- the Noir standard library, [noir-lang/noir](https://github.com/noir-lang/noir), Apache-2.0;
- [noir-lang/poseidon](https://github.com/noir-lang/poseidon), Apache-2.0;
- [BermudaBay/schnorr](https://github.com/BermudaBay/schnorr), a fork of
  [noir-lang/schnorr](https://github.com/noir-lang/schnorr), Apache-2.0.

The Apache License, Version 2.0 is available at <https://www.apache.org/licenses/LICENSE-2.0>.
